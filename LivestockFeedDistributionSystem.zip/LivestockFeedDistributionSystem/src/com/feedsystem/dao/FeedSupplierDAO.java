package com.feedsystem.dao;

import com.feedsystem.model.FeedSupplier;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for FeedSupplier entity
 */
public class FeedSupplierDAO {
    
    private Connection connection;
    
    public FeedSupplierDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE - Add new supplier
    public boolean addSupplier(FeedSupplier supplier) throws SQLException {
        String query = "INSERT INTO feed_suppliers (company_name, contact_person, email, phone, " +
                       "address, city, registration_number, rating) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, supplier.getCompanyName());
            pstmt.setString(2, supplier.getContactPerson());
            pstmt.setString(3, supplier.getEmail());
            pstmt.setString(4, supplier.getPhone());
            pstmt.setString(5, supplier.getAddress());
            pstmt.setString(6, supplier.getCity());
            pstmt.setString(7, supplier.getRegistrationNumber());
            pstmt.setDouble(8, supplier.getRating());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // READ - Get supplier by ID
    public FeedSupplier getSupplierById(int supplierId) throws SQLException {
        String query = "SELECT * FROM feed_suppliers WHERE supplier_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, supplierId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractSupplierFromResultSet(rs);
            }
        }
        return null;
    }
    
    // READ - Get all suppliers
    public List<FeedSupplier> getAllSuppliers() throws SQLException {
        List<FeedSupplier> suppliers = new ArrayList<>();
        String query = "SELECT * FROM feed_suppliers ORDER BY supplier_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                suppliers.add(extractSupplierFromResultSet(rs));
            }
        }
        return suppliers;
    }
    
    // UPDATE - Update existing supplier
    public boolean updateSupplier(FeedSupplier supplier) throws SQLException {
        String query = "UPDATE feed_suppliers SET company_name=?, contact_person=?, email=?, " +
                       "phone=?, address=?, city=?, registration_number=?, rating=? " +
                       "WHERE supplier_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, supplier.getCompanyName());
            pstmt.setString(2, supplier.getContactPerson());
            pstmt.setString(3, supplier.getEmail());
            pstmt.setString(4, supplier.getPhone());
            pstmt.setString(5, supplier.getAddress());
            pstmt.setString(6, supplier.getCity());
            pstmt.setString(7, supplier.getRegistrationNumber());
            pstmt.setDouble(8, supplier.getRating());
            pstmt.setInt(9, supplier.getSupplierId());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // DELETE - Delete supplier
    public boolean deleteSupplier(int supplierId) throws SQLException {
        String query = "DELETE FROM feed_suppliers WHERE supplier_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, supplierId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // SEARCH - Search suppliers
    public List<FeedSupplier> searchSuppliers(String searchTerm) throws SQLException {
        List<FeedSupplier> suppliers = new ArrayList<>();
        String query = "SELECT * FROM feed_suppliers WHERE company_name LIKE ? OR " +
                       "contact_person LIKE ? OR city LIKE ? OR email LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                suppliers.add(extractSupplierFromResultSet(rs));
            }
        }
        return suppliers;
    }
    
    // CHECK - Check if email exists
    public boolean emailExists(String email) throws SQLException {
        String query = "SELECT COUNT(*) FROM feed_suppliers WHERE email = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    
    // Helper method
    private FeedSupplier extractSupplierFromResultSet(ResultSet rs) throws SQLException {
        FeedSupplier supplier = new FeedSupplier();
        supplier.setSupplierId(rs.getInt("supplier_id"));
        supplier.setCompanyName(rs.getString("company_name"));
        supplier.setContactPerson(rs.getString("contact_person"));
        supplier.setEmail(rs.getString("email"));
        supplier.setPhone(rs.getString("phone"));
        supplier.setAddress(rs.getString("address"));
        supplier.setCity(rs.getString("city"));
        supplier.setRegistrationNumber(rs.getString("registration_number"));
        supplier.setRating(rs.getDouble("rating"));
        supplier.setCreatedAt(rs.getTimestamp("created_at"));
        return supplier;
    }
}