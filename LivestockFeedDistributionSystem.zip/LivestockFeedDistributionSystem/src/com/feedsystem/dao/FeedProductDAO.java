package com.feedsystem.dao;

import com.feedsystem.model.FeedProduct;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for FeedProduct entity
 */
public class FeedProductDAO {
    
    private Connection connection;
    
    public FeedProductDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE - Add new product
    public boolean addProduct(FeedProduct product) throws SQLException {
        String query = "INSERT INTO feed_products (supplier_id, product_name, feed_type, " +
                       "livestock_type, price_per_kg, stock_quantity, protein_content, " +
                       "manufacturer, description, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, product.getSupplierId());
            pstmt.setString(2, product.getProductName());
            pstmt.setString(3, product.getFeedType());
            pstmt.setString(4, product.getLivestockType());
            pstmt.setDouble(5, product.getPricePerKg());
            pstmt.setInt(6, product.getStockQuantity());
            pstmt.setDouble(7, product.getProteinContent());
            pstmt.setString(8, product.getManufacturer());
            pstmt.setString(9, product.getDescription());
            pstmt.setString(10, product.getStatus());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // READ - Get product by ID (with supplier info)
    public FeedProduct getProductById(int productId) throws SQLException {
        String query = "SELECT p.*, s.company_name as supplier_name " +
                       "FROM feed_products p " +
                       "JOIN feed_suppliers s ON p.supplier_id = s.supplier_id " +
                       "WHERE p.product_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractProductFromResultSet(rs);
            }
        }
        return null;
    }
    
    // READ - Get all products (with supplier info)
    public List<FeedProduct> getAllProducts() throws SQLException {
        List<FeedProduct> products = new ArrayList<>();
        String query = "SELECT p.*, s.company_name as supplier_name " +
                       "FROM feed_products p " +
                       "JOIN feed_suppliers s ON p.supplier_id = s.supplier_id " +
                       "ORDER BY p.product_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                products.add(extractProductFromResultSet(rs));
            }
        }
        return products;
    }
    
    // READ - Get available products only
    public List<FeedProduct> getAvailableProducts() throws SQLException {
        List<FeedProduct> products = new ArrayList<>();
        String query = "SELECT p.*, s.company_name as supplier_name " +
                       "FROM feed_products p " +
                       "JOIN feed_suppliers s ON p.supplier_id = s.supplier_id " +
                       "WHERE p.status = 'AVAILABLE' AND p.stock_quantity > 0 " +
                       "ORDER BY p.product_name";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                products.add(extractProductFromResultSet(rs));
            }
        }
        return products;
    }
    
    // UPDATE - Update existing product
    public boolean updateProduct(FeedProduct product) throws SQLException {
        String query = "UPDATE feed_products SET supplier_id=?, product_name=?, feed_type=?, " +
                       "livestock_type=?, price_per_kg=?, stock_quantity=?, protein_content=?, " +
                       "manufacturer=?, description=?, status=? WHERE product_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, product.getSupplierId());
            pstmt.setString(2, product.getProductName());
            pstmt.setString(3, product.getFeedType());
            pstmt.setString(4, product.getLivestockType());
            pstmt.setDouble(5, product.getPricePerKg());
            pstmt.setInt(6, product.getStockQuantity());
            pstmt.setDouble(7, product.getProteinContent());
            pstmt.setString(8, product.getManufacturer());
            pstmt.setString(9, product.getDescription());
            pstmt.setString(10, product.getStatus());
            pstmt.setInt(11, product.getProductId());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // UPDATE - Update stock quantity
    public boolean updateStock(int productId, int newQuantity) throws SQLException {
        String query = "UPDATE feed_products SET stock_quantity = ? WHERE product_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, newQuantity);
            pstmt.setInt(2, productId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // UPDATE - Reduce stock (for orders)
    public boolean reduceStock(int productId, int quantity) throws SQLException {
        String query = "UPDATE feed_products SET stock_quantity = stock_quantity - ? " +
                       "WHERE product_id = ? AND stock_quantity >= ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, productId);
            pstmt.setInt(3, quantity);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // DELETE - Delete product
    public boolean deleteProduct(int productId) throws SQLException {
        String query = "DELETE FROM feed_products WHERE product_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, productId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // SEARCH - Search products
    public List<FeedProduct> searchProducts(String searchTerm) throws SQLException {
        List<FeedProduct> products = new ArrayList<>();
        String query = "SELECT p.*, s.company_name as supplier_name " +
                       "FROM feed_products p " +
                       "JOIN feed_suppliers s ON p.supplier_id = s.supplier_id " +
                       "WHERE p.product_name LIKE ? OR p.feed_type LIKE ? OR " +
                       "p.livestock_type LIKE ? OR p.manufacturer LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                products.add(extractProductFromResultSet(rs));
            }
        }
        return products;
    }
    
    // Helper method
    private FeedProduct extractProductFromResultSet(ResultSet rs) throws SQLException {
        FeedProduct product = new FeedProduct();
        product.setProductId(rs.getInt("product_id"));
        product.setSupplierId(rs.getInt("supplier_id"));
        product.setProductName(rs.getString("product_name"));
        product.setFeedType(rs.getString("feed_type"));
        product.setLivestockType(rs.getString("livestock_type"));
        product.setPricePerKg(rs.getDouble("price_per_kg"));
        product.setStockQuantity(rs.getInt("stock_quantity"));
        product.setProteinContent(rs.getDouble("protein_content"));
        product.setManufacturer(rs.getString("manufacturer"));
        product.setDescription(rs.getString("description"));
        product.setStatus(rs.getString("status"));
        product.setCreatedAt(rs.getTimestamp("created_at"));
        
        // From JOIN
        product.setSupplierName(rs.getString("supplier_name"));
        
        return product;
    }
}