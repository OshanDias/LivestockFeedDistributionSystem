package com.feedsystem.dao;

import com.feedsystem.model.FeedOrder;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for FeedOrder entity - MAIN TRANSACTION
 */
public class FeedOrderDAO {
    
    private Connection connection;
    
    public FeedOrderDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE - Add new order
    public boolean addOrder(FeedOrder order) throws SQLException {
        String query = "INSERT INTO feed_orders (farmer_id, product_id, order_date, " +
                       "delivery_date, quantity_kg, price_per_kg, total_amount, " +
                       "delivery_address, payment_status, delivery_status, notes) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, order.getFarmerId());
            pstmt.setInt(2, order.getProductId());
            pstmt.setDate(3, order.getOrderDate());
            pstmt.setDate(4, order.getDeliveryDate());
            pstmt.setInt(5, order.getQuantityKg());
            pstmt.setDouble(6, order.getPricePerKg());
            pstmt.setDouble(7, order.getTotalAmount());
            pstmt.setString(8, order.getDeliveryAddress());
            pstmt.setString(9, order.getPaymentStatus());
            pstmt.setString(10, order.getDeliveryStatus());
            pstmt.setString(11, order.getNotes());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // READ - Get order by ID (with farmer and product info)
    public FeedOrder getOrderById(int orderId) throws SQLException {
        String query = "SELECT o.*, " +
                       "CONCAT(f.first_name, ' ', f.last_name) as farmer_name, " +
                       "f.phone as farmer_phone, " +
                       "p.product_name, " +
                       "p.feed_type " +
                       "FROM feed_orders o " +
                       "JOIN livestock_farmers f ON o.farmer_id = f.farmer_id " +
                       "JOIN feed_products p ON o.product_id = p.product_id " +
                       "WHERE o.order_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractOrderFromResultSet(rs);
            }
        }
        return null;
    }
    
    // READ - Get all orders (with farmer and product info)
    public List<FeedOrder> getAllOrders() throws SQLException {
        List<FeedOrder> orders = new ArrayList<>();
        String query = "SELECT o.*, " +
                       "CONCAT(f.first_name, ' ', f.last_name) as farmer_name, " +
                       "f.phone as farmer_phone, " +
                       "p.product_name, " +
                       "p.feed_type " +
                       "FROM feed_orders o " +
                       "JOIN livestock_farmers f ON o.farmer_id = f.farmer_id " +
                       "JOIN feed_products p ON o.product_id = p.product_id " +
                       "ORDER BY o.order_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                orders.add(extractOrderFromResultSet(rs));
            }
        }
        return orders;
    }
    
    // READ - Get orders by status
    public List<FeedOrder> getOrdersByStatus(String deliveryStatus) throws SQLException {
        List<FeedOrder> orders = new ArrayList<>();
        String query = "SELECT o.*, " +
                       "CONCAT(f.first_name, ' ', f.last_name) as farmer_name, " +
                       "f.phone as farmer_phone, " +
                       "p.product_name, " +
                       "p.feed_type " +
                       "FROM feed_orders o " +
                       "JOIN livestock_farmers f ON o.farmer_id = f.farmer_id " +
                       "JOIN feed_products p ON o.product_id = p.product_id " +
                       "WHERE o.delivery_status = ? " +
                       "ORDER BY o.delivery_date";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, deliveryStatus);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                orders.add(extractOrderFromResultSet(rs));
            }
        }
        return orders;
    }
    
    // READ - Get pending orders
    public List<FeedOrder> getPendingOrders() throws SQLException {
        return getOrdersByStatus("PROCESSING");
    }
    
    // UPDATE - Update existing order
    public boolean updateOrder(FeedOrder order) throws SQLException {
        String query = "UPDATE feed_orders SET farmer_id=?, product_id=?, order_date=?, " +
                       "delivery_date=?, quantity_kg=?, price_per_kg=?, total_amount=?, " +
                       "delivery_address=?, payment_status=?, delivery_status=?, notes=? " +
                       "WHERE order_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, order.getFarmerId());
            pstmt.setInt(2, order.getProductId());
            pstmt.setDate(3, order.getOrderDate());
            pstmt.setDate(4, order.getDeliveryDate());
            pstmt.setInt(5, order.getQuantityKg());
            pstmt.setDouble(6, order.getPricePerKg());
            pstmt.setDouble(7, order.getTotalAmount());
            pstmt.setString(8, order.getDeliveryAddress());
            pstmt.setString(9, order.getPaymentStatus());
            pstmt.setString(10, order.getDeliveryStatus());
            pstmt.setString(11, order.getNotes());
            pstmt.setInt(12, order.getOrderId());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // UPDATE - Update delivery status
    public boolean updateDeliveryStatus(int orderId, String newStatus) throws SQLException {
        String query = "UPDATE feed_orders SET delivery_status = ? WHERE order_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // UPDATE - Update payment status
    public boolean updatePaymentStatus(int orderId, String newStatus) throws SQLException {
        String query = "UPDATE feed_orders SET payment_status = ? WHERE order_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // DELETE - Delete order
    public boolean deleteOrder(int orderId) throws SQLException {
        String query = "DELETE FROM feed_orders WHERE order_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // STATISTICS - Get total sales
    public double getTotalSales() throws SQLException {
        String query = "SELECT SUM(total_amount) as total FROM feed_orders " +
                       "WHERE delivery_status = 'DELIVERED'";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
        }
        return 0.0;
    }
    
    // STATISTICS - Get order count by status
    public int getOrderCountByStatus(String status) throws SQLException {
        String query = "SELECT COUNT(*) FROM feed_orders WHERE delivery_status = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
    
    // Helper method
    private FeedOrder extractOrderFromResultSet(ResultSet rs) throws SQLException {
        FeedOrder order = new FeedOrder();
        order.setOrderId(rs.getInt("order_id"));
        order.setFarmerId(rs.getInt("farmer_id"));
        order.setProductId(rs.getInt("product_id"));
        order.setOrderDate(rs.getDate("order_date"));
        order.setDeliveryDate(rs.getDate("delivery_date"));
        order.setQuantityKg(rs.getInt("quantity_kg"));
        order.setPricePerKg(rs.getDouble("price_per_kg"));
        order.setTotalAmount(rs.getDouble("total_amount"));
        order.setDeliveryAddress(rs.getString("delivery_address"));
        order.setPaymentStatus(rs.getString("payment_status"));
        order.setDeliveryStatus(rs.getString("delivery_status"));
        order.setNotes(rs.getString("notes"));
        order.setCreatedAt(rs.getTimestamp("created_at"));
        
        // From JOINs
        order.setFarmerName(rs.getString("farmer_name"));
        order.setFarmerPhone(rs.getString("farmer_phone"));
        order.setProductName(rs.getString("product_name"));
        order.setFeedType(rs.getString("feed_type"));
        
        return order;
    }
}