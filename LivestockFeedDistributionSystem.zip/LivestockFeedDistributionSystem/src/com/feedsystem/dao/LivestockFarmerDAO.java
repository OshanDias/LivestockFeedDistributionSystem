package com.feedsystem.dao;

import com.feedsystem.model.LivestockFarmer;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for LivestockFarmer entity
 */
public class LivestockFarmerDAO {
    
    private Connection connection;
    
    public LivestockFarmerDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    // CREATE - Add new farmer
    public boolean addFarmer(LivestockFarmer farmer) throws SQLException {
        String query = "INSERT INTO livestock_farmers (first_name, last_name, email, phone, " +
                       "nic, address, farm_location, farm_size, livestock_type, livestock_count) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, farmer.getFirstName());
            pstmt.setString(2, farmer.getLastName());
            pstmt.setString(3, farmer.getEmail());
            pstmt.setString(4, farmer.getPhone());
            pstmt.setString(5, farmer.getNic());
            pstmt.setString(6, farmer.getAddress());
            pstmt.setString(7, farmer.getFarmLocation());
            pstmt.setDouble(8, farmer.getFarmSize());
            pstmt.setString(9, farmer.getLivestockType());
            pstmt.setInt(10, farmer.getLivestockCount());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // READ - Get farmer by ID
    public LivestockFarmer getFarmerById(int farmerId) throws SQLException {
        String query = "SELECT * FROM livestock_farmers WHERE farmer_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, farmerId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractFarmerFromResultSet(rs);
            }
        }
        return null;
    }
    
    // READ - Get all farmers
    public List<LivestockFarmer> getAllFarmers() throws SQLException {
        List<LivestockFarmer> farmers = new ArrayList<>();
        String query = "SELECT * FROM livestock_farmers ORDER BY farmer_id DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                farmers.add(extractFarmerFromResultSet(rs));
            }
        }
        return farmers;
    }
    
    // UPDATE - Update existing farmer
    public boolean updateFarmer(LivestockFarmer farmer) throws SQLException {
        String query = "UPDATE livestock_farmers SET first_name=?, last_name=?, email=?, " +
                       "phone=?, nic=?, address=?, farm_location=?, farm_size=?, " +
                       "livestock_type=?, livestock_count=? WHERE farmer_id=?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, farmer.getFirstName());
            pstmt.setString(2, farmer.getLastName());
            pstmt.setString(3, farmer.getEmail());
            pstmt.setString(4, farmer.getPhone());
            pstmt.setString(5, farmer.getNic());
            pstmt.setString(6, farmer.getAddress());
            pstmt.setString(7, farmer.getFarmLocation());
            pstmt.setDouble(8, farmer.getFarmSize());
            pstmt.setString(9, farmer.getLivestockType());
            pstmt.setInt(10, farmer.getLivestockCount());
            pstmt.setInt(11, farmer.getFarmerId());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // DELETE - Delete farmer
    public boolean deleteFarmer(int farmerId) throws SQLException {
        String query = "DELETE FROM livestock_farmers WHERE farmer_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, farmerId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // SEARCH - Search farmers
    public List<LivestockFarmer> searchFarmers(String searchTerm) throws SQLException {
        List<LivestockFarmer> farmers = new ArrayList<>();
        String query = "SELECT * FROM livestock_farmers WHERE first_name LIKE ? OR " +
                       "last_name LIKE ? OR phone LIKE ? OR email LIKE ? OR " +
                       "farm_location LIKE ? OR livestock_type LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            String searchPattern = "%" + searchTerm + "%";
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);
            pstmt.setString(3, searchPattern);
            pstmt.setString(4, searchPattern);
            pstmt.setString(5, searchPattern);
            pstmt.setString(6, searchPattern);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                farmers.add(extractFarmerFromResultSet(rs));
            }
        }
        return farmers;
    }
    
    // CHECK - Check if email exists
    public boolean emailExists(String email) throws SQLException {
        String query = "SELECT COUNT(*) FROM livestock_farmers WHERE email = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    
    // CHECK - Check if NIC exists
    public boolean nicExists(String nic) throws SQLException {
        String query = "SELECT COUNT(*) FROM livestock_farmers WHERE nic = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, nic);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    
    // Helper method
    private LivestockFarmer extractFarmerFromResultSet(ResultSet rs) throws SQLException {
        LivestockFarmer farmer = new LivestockFarmer();
        farmer.setFarmerId(rs.getInt("farmer_id"));
        farmer.setFirstName(rs.getString("first_name"));
        farmer.setLastName(rs.getString("last_name"));
        farmer.setEmail(rs.getString("email"));
        farmer.setPhone(rs.getString("phone"));
        farmer.setNic(rs.getString("nic"));
        farmer.setAddress(rs.getString("address"));
        farmer.setFarmLocation(rs.getString("farm_location"));
        farmer.setFarmSize(rs.getDouble("farm_size"));
        farmer.setLivestockType(rs.getString("livestock_type"));
        farmer.setLivestockCount(rs.getInt("livestock_count"));
        farmer.setCreatedAt(rs.getTimestamp("created_at"));
        return farmer;
    }
}