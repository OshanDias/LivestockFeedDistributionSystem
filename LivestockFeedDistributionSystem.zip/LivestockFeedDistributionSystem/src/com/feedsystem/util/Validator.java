package com.feedsystem.util;

import java.sql.Date;
import java.time.LocalDate;
import java.util.regex.Pattern;

/**
 * Utility class for input validation
 */
public class Validator {
    
    // Email validation pattern
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    
    // Phone validation pattern (Sri Lankan format)
    private static final Pattern PHONE_PATTERN = 
        Pattern.compile("^0[0-9]{9}$");
    
    // NIC validation patterns (Sri Lankan format)
    private static final Pattern NIC_OLD_PATTERN = 
        Pattern.compile("^[0-9]{9}[VvXx]$");
    private static final Pattern NIC_NEW_PATTERN = 
        Pattern.compile("^[0-9]{12}$");
    
    // Check if string is empty or null
    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }
    
    // Validate email format
    public static boolean isValidEmail(String email) {
        if (isEmpty(email)) return false;
        return EMAIL_PATTERN.matcher(email).matches();
    }
    
    // Validate phone number
    public static boolean isValidPhone(String phone) {
        if (isEmpty(phone)) return false;
        return PHONE_PATTERN.matcher(phone).matches();
    }
    
    // Validate NIC (both old and new formats)
    public static boolean isValidNIC(String nic) {
        if (isEmpty(nic)) return false;
        return NIC_OLD_PATTERN.matcher(nic).matches() || 
               NIC_NEW_PATTERN.matcher(nic).matches();
    }
    
    // Validate date (not in past)
    public static boolean isValidFutureDate(Date date) {
        if (date == null) return false;
        LocalDate inputDate = date.toLocalDate();
        LocalDate today = LocalDate.now();
        return !inputDate.isBefore(today);
    }
    
    // Validate date range
    public static boolean isValidDateRange(Date startDate, Date endDate) {
        if (startDate == null || endDate == null) return false;
        return !endDate.before(startDate);
    }
    
    // Validate positive number
    public static boolean isPositiveNumber(double number) {
        return number > 0;
    }
    
    // Validate positive integer
    public static boolean isPositiveInteger(int number) {
        return number > 0;
    }
    
    // Validate string length
    public static boolean isValidLength(String str, int minLength, int maxLength) {
        if (isEmpty(str)) return false;
        int length = str.trim().length();
        return length >= minLength && length <= maxLength;
    }
    
    // Validate that string contains only letters and spaces
    public static boolean isValidName(String name) {
        if (isEmpty(name)) return false;
        return name.matches("^[a-zA-Z ]+$");
    }
    
    // Validate rating (0.0 to 5.0)
    public static boolean isValidRating(double rating) {
        return rating >= 0.0 && rating <= 5.0;
    }
}