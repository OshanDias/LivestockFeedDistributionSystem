package com.feedsystem.view;

import com.feedsystem.controller.ReportController;
import com.feedsystem.dao.*;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

/**
 * Dashboard Form - COMPACT SIDEBAR LAYOUT - Purple Theme
 */
public class DashboardForm extends JFrame {
    
    private FeedSupplierDAO supplierDAO;
    private FeedProductDAO productDAO;
    private LivestockFarmerDAO farmerDAO;
    private FeedOrderDAO orderDAO;
    
    public DashboardForm() {
        supplierDAO = new FeedSupplierDAO();
        productDAO = new FeedProductDAO();
        farmerDAO = new LivestockFarmerDAO();
        orderDAO = new FeedOrderDAO();
        initComponents();
        loadStatistics();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings - SMALLER SIZE
        setTitle("Livestock Feed Distribution System - Dashboard");
        setSize(1400, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(250, 245, 255));
        
        // Header Panel - Purple
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(142, 68, 173));
        headerPanel.setBounds(0, 0, 1400, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel("🐄 L.F.S DISTRIBUTIONS - DASHBOARD");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 600, 30);
        headerPanel.add(lblTitle);
        
        // Logout Button
        JButton btnLogout = createHeaderButton("LOGOUT", 1250, 15);
        btnLogout.addActionListener(e -> logout());
        headerPanel.add(btnLogout);
        
        // LEFT SIDEBAR - COMPACT
        JPanel sidebarPanel = new JPanel();
        sidebarPanel.setLayout(null);
        sidebarPanel.setBackground(new Color(103, 58, 183));
        sidebarPanel.setBounds(0, 60, 200, 690);
        add(sidebarPanel);
        
        // Sidebar Title
        JLabel lblSidebarTitle = new JLabel("QUICK ACCESS", SwingConstants.CENTER);
        lblSidebarTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSidebarTitle.setForeground(Color.WHITE);
        lblSidebarTitle.setBounds(0, 15, 200, 25);
        sidebarPanel.add(lblSidebarTitle);
        
        // Sidebar Menu Buttons - COMPACT
        int yPos = 60;
        int gap = 65;
        
        JButton btnSuppliers = createSidebarButton(" Suppliers", yPos);
        btnSuppliers.addActionListener(e -> openSupplierManagement());
        sidebarPanel.add(btnSuppliers);
        
        yPos += gap;
        JButton btnProducts = createSidebarButton(" Products", yPos);
        btnProducts.addActionListener(e -> openProductManagement());
        sidebarPanel.add(btnProducts);
        
        yPos += gap;
        JButton btnFarmers = createSidebarButton("👨‍🌾 Farmers", yPos);
        btnFarmers.addActionListener(e -> openFarmerManagement());
        sidebarPanel.add(btnFarmers);
        
        yPos += gap;
        JButton btnOrders = createSidebarButton(" Orders", yPos);
        btnOrders.addActionListener(e -> openOrderManagement());
        sidebarPanel.add(btnOrders);
        
        yPos += gap;
        JButton btnReport = createSidebarButton(" Report", yPos);
        btnReport.addActionListener(e -> generateReport());
        sidebarPanel.add(btnReport);
        
        yPos += gap;
        JButton btnRefresh = createSidebarButton(" Refresh", yPos);
        btnRefresh.addActionListener(e -> loadStatistics());
        sidebarPanel.add(btnRefresh);
        
        // MAIN CONTENT AREA - COMPACT
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(250, 245, 255));
        mainPanel.setBounds(200, 60, 1200, 690);
        add(mainPanel);
        
        // Welcome Section - SMALLER
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(null);
        welcomePanel.setBackground(Color.WHITE);
        welcomePanel.setBounds(20, 20, 1160, 80);
        welcomePanel.setBorder(BorderFactory.createLineBorder(new Color(155, 89, 182), 2));
        mainPanel.add(welcomePanel);
        
        JLabel lblWelcome = new JLabel("Welcome to Livestock Feed Distribution System");
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblWelcome.setForeground(new Color(103, 58, 183));
        lblWelcome.setBounds(25, 15, 700, 25);
        welcomePanel.add(lblWelcome);
        
        JLabel lblSubtext = new JLabel("Manage suppliers, products, farmers, and orders efficiently");
        lblSubtext.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubtext.setForeground(new Color(120, 120, 120));
        lblSubtext.setBounds(25, 45, 500, 20);
        welcomePanel.add(lblSubtext);
        
        // Statistics Cards - COMPACT 2x2 GRID
        JPanel statsPanel = new JPanel();
        statsPanel.setLayout(null);
        statsPanel.setBackground(new Color(250, 245, 255));
        statsPanel.setBounds(20, 115, 1160, 280);
        mainPanel.add(statsPanel);
        
        // Row 1
        createStatCard(statsPanel, " TOTAL SUPPLIERS", "0", new Color(142, 68, 173), 0, 0);
        createStatCard(statsPanel, " TOTAL PRODUCTS", "0", new Color(155, 89, 182), 590, 0);
        
        // Row 2
        createStatCard(statsPanel, "👨‍🌾 TOTAL FARMERS", "0", new Color(171, 130, 195), 0, 145);
        createStatCard(statsPanel, " TOTAL SALES", "Rs. 0.00", new Color(103, 58, 183), 590, 145);
        
        // Quick Info Panel - COMPACT
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(null);
        infoPanel.setBackground(Color.WHITE);
        infoPanel.setBounds(20, 410, 1160, 260);
        infoPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            "System Overview",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(103, 58, 183)
        ));
        mainPanel.add(infoPanel);
        
        // Info Text - COMPACT
        JTextArea txtInfo = new JTextArea();
        txtInfo.setEditable(false);
        txtInfo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        txtInfo.setLineWrap(true);
        txtInfo.setWrapStyleWord(true);
        txtInfo.setBackground(Color.WHITE);
        txtInfo.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        txtInfo.setText(
            " SYSTEM FEATURES:\n\n" +
            "• Manage Feed Suppliers - Add, update, and track feed suppliers\n" +
            "• Manage Feed Products - Track inventory, prices, and stock levels\n" +
            "• Manage Livestock Farmers - Maintain farmer database with livestock details\n" +
            "• Process Orders - Create and track feed orders with delivery management\n" +
            "• Generate Reports - Sales analysis by feed type with 3-table JOIN\n\n" +
            "Use the sidebar menu to navigate to different sections.\n" +
            "Click Refresh to update dashboard statistics."
        );
        
        JScrollPane scrollInfo = new JScrollPane(txtInfo);
        scrollInfo.setBounds(15, 35, 1130, 210);
        scrollInfo.setBorder(null);
        infoPanel.add(scrollInfo);
    }
    
    private void createStatCard(JPanel parent, String title, String value, Color color, int x, int y) {
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBackground(color);
        card.setBounds(x, y, 570, 130);
        card.setBorder(BorderFactory.createLineBorder(color.darker(), 2));
        
        JLabel lblTitle = new JLabel(title, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(10, 20, 550, 25);
        card.add(lblTitle);
        
        JLabel lblValue = new JLabel(value, SwingConstants.CENTER);
        lblValue.setFont(new Font("Segoe UI", Font.BOLD, 36));
        lblValue.setForeground(Color.WHITE);
        lblValue.setBounds(10, 60, 550, 50);
        lblValue.setName(title);
        card.add(lblValue);
        
        parent.add(card);
    }
    
    private JButton createSidebarButton(String text, int y) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(10, y, 180, 50);
        btn.setBackground(new Color(123, 78, 203));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(155, 89, 182));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(123, 78, 203));
            }
        });
        
        return btn;
    }
    
    private JButton createHeaderButton(String text, int x, int y) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, 120, 32);
        btn.setBackground(new Color(231, 76, 60));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
    
    private void loadStatistics() {
        try {
            int totalSuppliers = supplierDAO.getAllSuppliers().size();
            int totalProducts = productDAO.getAllProducts().size();
            int totalFarmers = farmerDAO.getAllFarmers().size();
            double totalSales = orderDAO.getTotalSales();
            
            updateStatCard(" TOTAL SUPPLIERS", String.valueOf(totalSuppliers));
            updateStatCard(" TOTAL PRODUCTS", String.valueOf(totalProducts));
            updateStatCard("👨‍🌾 TOTAL FARMERS", String.valueOf(totalFarmers));
            updateStatCard(" TOTAL SALES", "Rs. " + String.format("%.2f", totalSales));
            
            System.out.println("✅ Dashboard statistics loaded!");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading statistics: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateStatCard(String title, String value) {
        Component[] components = getContentPane().getComponents();
        for (Component comp : components) {
            if (comp instanceof JPanel) {
                updateStatCardRecursive((JPanel) comp, title, value);
            }
        }
    }
    
    private void updateStatCardRecursive(JPanel panel, String title, String value) {
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JPanel) {
                updateStatCardRecursive((JPanel) comp, title, value);
            } else if (comp instanceof JLabel) {
                JLabel label = (JLabel) comp;
                if (title.equals(label.getName())) {
                    label.setText(value);
                }
            }
        }
    }
    
    private void openSupplierManagement() {
        SupplierForm supplierForm = new SupplierForm();
        supplierForm.setVisible(true);
    }
    
    private void openProductManagement() {
        ProductForm productForm = new ProductForm();
        productForm.setVisible(true);
    }
    
    private void openFarmerManagement() {
        FarmerForm farmerForm = new FarmerForm();
        farmerForm.setVisible(true);
    }
    
    private void openOrderManagement() {
        OrderForm orderForm = new OrderForm();
        orderForm.setVisible(true);
    }
    
    private void generateReport() {
        JOptionPane.showMessageDialog(this,
            "📊 Generating Sales Report...\nPlease wait...",
            "Report Generation",
            JOptionPane.INFORMATION_MESSAGE);
        
        ReportController reportController = new ReportController();
        reportController.generateSalesReport();
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
        }
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new DashboardForm().setVisible(true));
    }
}