package com.feedsystem.view;

import com.feedsystem.dao.FeedProductDAO;
import com.feedsystem.dao.FeedSupplierDAO;
import com.feedsystem.model.FeedProduct;
import com.feedsystem.model.FeedSupplier;
import com.feedsystem.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Product Management Form - TOP-BOTTOM LAYOUT
 */
public class ProductForm extends JFrame {
    
    private FeedProductDAO productDAO;
    private FeedSupplierDAO supplierDAO;
    private DefaultTableModel tableModel;
    
    // Components
    private JTable tblProducts;
    private JComboBox<String> cmbSupplier;
    private JTextField txtProductName;
    private JComboBox<String> cmbFeedType;
    private JComboBox<String> cmbLivestockType;
    private JTextField txtPricePerKg;
    private JTextField txtStockQuantity;
    private JTextField txtProteinContent;
    private JTextField txtManufacturer;
    private JTextArea txtDescription;
    private JComboBox<String> cmbStatus;
    private JTextField txtSearch;
    
    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;
    private JButton btnSearch;
    private JButton btnRefresh;
    private JButton btnBack;
    
    private int selectedProductId = -1;
    
    public ProductForm() {
        productDAO = new FeedProductDAO();
        supplierDAO = new FeedSupplierDAO();
        initComponents();
        loadProducts();
        loadSuppliers();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings
        setTitle("Product Management");
        setSize(1400, 850);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(250, 245, 255));
        
        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(142, 68, 173));
        headerPanel.setBounds(0, 0, 1400, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel(" PRODUCT MANAGEMENT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 400, 30);
        headerPanel.add(lblTitle);
        
        // Back Button
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setBounds(1250, 15, 120, 32);
        btnBack.setBackground(new Color(231, 76, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // TOP SECTION - INPUT FORM
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);
        inputPanel.setBackground(Color.WHITE);
        inputPanel.setBounds(20, 80, 1360, 360);
        inputPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(142, 68, 173), 2),
            "Product Information",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(103, 58, 183)
        ));
        add(inputPanel);
        
        // COLUMN 1
        int col1X = 30;
        int yPos = 40;
        int gap = 70;
        
        addLabel(inputPanel, "Supplier:", col1X, yPos);
        cmbSupplier = addComboBox(inputPanel, col1X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Feed Type:", col1X, yPos);
        String[] feedTypes = {"Grain", "Pellets", "Supplement", "Mineral", "Mixed"};
        cmbFeedType = addComboBox(inputPanel, col1X, yPos + 25, 580, feedTypes);
        
        yPos += gap;
        addLabel(inputPanel, "Price per KG (Rs):", col1X, yPos);
        txtPricePerKg = addTextField(inputPanel, col1X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Protein Content (%):", col1X, yPos);
        txtProteinContent = addTextField(inputPanel, col1X, yPos + 25, 580);
        
        // COLUMN 2
        int col2X = 680;
        yPos = 40;
        
        addLabel(inputPanel, "Product Name:", col2X, yPos);
        txtProductName = addTextField(inputPanel, col2X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Livestock Type:", col2X, yPos);
        String[] livestockTypes = {"Cattle", "Poultry", "Goat", "Sheep", "Pig", "Multi-Purpose"};
        cmbLivestockType = addComboBox(inputPanel, col2X, yPos + 25, 580, livestockTypes);
        
        yPos += gap;
        addLabel(inputPanel, "Stock Quantity (KG):", col2X, yPos);
        txtStockQuantity = addTextField(inputPanel, col2X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Manufacturer:", col2X, yPos);
        txtManufacturer = addTextField(inputPanel, col2X, yPos + 25, 580);
        
        // Action Buttons
        int btnY = 310;
        int btnStartX = 350;
        
        btnAdd = createButton(" ADD", btnStartX, btnY, new Color(46, 204, 113), 150);
        btnAdd.addActionListener(e -> addProduct());
        inputPanel.add(btnAdd);
        
        btnUpdate = createButton(" UPDATE", btnStartX + 160, btnY, new Color(142, 68, 173), 150);
        btnUpdate.addActionListener(e -> updateProduct());
        inputPanel.add(btnUpdate);
        
        btnDelete = createButton("🗑️ DELETE", btnStartX + 320, btnY, new Color(231, 76, 60), 150);
        btnDelete.addActionListener(e -> deleteProduct());
        inputPanel.add(btnDelete);
        
        btnClear = createButton(" CLEAR", btnStartX + 480, btnY, new Color(149, 165, 166), 150);
        btnClear.addActionListener(e -> clearFields());
        inputPanel.add(btnClear);
        
        // BOTTOM SECTION - TABLE
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(null);
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBounds(20, 460, 1360, 370);
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(142, 68, 173), 2),
            "Product Records",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(103, 58, 183)
        ));
        add(tablePanel);
        
        // Search Bar
        JLabel lblSearch = new JLabel(" Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSearch.setBounds(30, 35, 100, 35);
        tablePanel.add(lblSearch);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBounds(130, 35, 900, 35);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        tablePanel.add(txtSearch);
        
        btnSearch = createButton("SEARCH", 1050, 35, new Color(142, 68, 173), 130);
        btnSearch.addActionListener(e -> searchProducts());
        tablePanel.add(btnSearch);
        
        btnRefresh = createButton("REFRESH", 1195, 35, new Color(155, 89, 182), 130);
        btnRefresh.addActionListener(e -> loadProducts());
        tablePanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "Product Name", "Supplier", "Feed Type", "Livestock", "Price/KG", "Stock", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblProducts = new JTable(tableModel);
        tblProducts.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tblProducts.setRowHeight(28);
        tblProducts.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tblProducts.getTableHeader().setBackground(new Color(142, 68, 173));
        tblProducts.getTableHeader().setForeground(Color.WHITE);
        tblProducts.getTableHeader().setPreferredSize(new Dimension(0, 32));
        tblProducts.setSelectionBackground(new Color(155, 89, 182));
        tblProducts.setSelectionForeground(Color.WHITE);
        tblProducts.setGridColor(new Color(220, 220, 220));
        
        tblProducts.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedProduct();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblProducts);
        scrollPane.setBounds(30, 85, 1300, 270);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(155, 89, 182), 1));
        tablePanel.add(scrollPane);
    }
    
    // Helper methods
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(new Color(103, 58, 183));
        label.setBounds(x, y, 300, 20);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBounds(x, y, width, 35);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JComboBox<String> addComboBox(JPanel panel, int x, int y, int width) {
        JComboBox<String> combo = new JComboBox<>();
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        combo.setBounds(x, y, width, 35);
        panel.add(combo);
        return combo;
    }
    
    private JComboBox<String> addComboBox(JPanel panel, int x, int y, int width, String[] items) {
        JComboBox<String> combo = new JComboBox<>(items);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        combo.setBounds(x, y, width, 35);
        panel.add(combo);
        return combo;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, width, 38);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    // Load suppliers into combo
    private void loadSuppliers() {
        try {
            cmbSupplier.removeAllItems();
            List<FeedSupplier> suppliers = supplierDAO.getAllSuppliers();
            for (FeedSupplier supplier : suppliers) {
                cmbSupplier.addItem(supplier.getSupplierId() + " - " + supplier.getCompanyName());
            }
        } catch (SQLException e) {
            showError("Error loading suppliers: " + e.getMessage());
        }
    }
    
    // Load all products
    private void loadProducts() {
        try {
            tableModel.setRowCount(0);
            List<FeedProduct> products = productDAO.getAllProducts();
            
            for (FeedProduct product : products) {
                Object[] row = {
                    product.getProductId(),
                    product.getProductName(),
                    product.getSupplierName(),
                    product.getFeedType(),
                    product.getLivestockType(),
                    "Rs. " + String.format("%.2f", product.getPricePerKg()),
                    product.getStockQuantity() + " KG",
                    product.getStatus()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading products: " + e.getMessage());
        }
    }
    
    // Load selected product
    private void loadSelectedProduct() {
        int selectedRow = tblProducts.getSelectedRow();
        if (selectedRow >= 0) {
            selectedProductId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                FeedProduct product = productDAO.getProductById(selectedProductId);
                if (product != null) {
                    // Set supplier
                    for (int i = 0; i < cmbSupplier.getItemCount(); i++) {
                        if (cmbSupplier.getItemAt(i).startsWith(product.getSupplierId() + " - ")) {
                            cmbSupplier.setSelectedIndex(i);
                            break;
                        }
                    }
                    
                    txtProductName.setText(product.getProductName());
                    cmbFeedType.setSelectedItem(product.getFeedType());
                    cmbLivestockType.setSelectedItem(product.getLivestockType());
                    txtPricePerKg.setText(String.format("%.2f", product.getPricePerKg()));
                    txtStockQuantity.setText(String.valueOf(product.getStockQuantity()));
                    txtProteinContent.setText(String.format("%.2f", product.getProteinContent()));
                    txtManufacturer.setText(product.getManufacturer());
                }
            } catch (SQLException e) {
                showError("Error loading product details: " + e.getMessage());
            }
        }
    }
    
    // Add product
    private void addProduct() {
        if (!validateInputs()) return;
        
        try {
            String supplierStr = (String) cmbSupplier.getSelectedItem();
            int supplierId = Integer.parseInt(supplierStr.split(" - ")[0]);
            
            FeedProduct product = new FeedProduct();
            product.setSupplierId(supplierId);
            product.setProductName(txtProductName.getText().trim());
            product.setFeedType((String) cmbFeedType.getSelectedItem());
            product.setLivestockType((String) cmbLivestockType.getSelectedItem());
            product.setPricePerKg(Double.parseDouble(txtPricePerKg.getText().trim()));
            product.setStockQuantity(Integer.parseInt(txtStockQuantity.getText().trim()));
            product.setProteinContent(Double.parseDouble(txtProteinContent.getText().trim()));
            product.setManufacturer(txtManufacturer.getText().trim());
            product.setDescription("");
            product.setStatus("AVAILABLE");
            
            boolean success = productDAO.addProduct(product);
            
            if (success) {
                showSuccess("✅ Product added successfully!");
                loadProducts();
                clearFields();
            } else {
                showError("Failed to add product!");
            }
            
        } catch (SQLException e) {
            showError("Error adding product: " + e.getMessage());
        }
    }
    
    // Update product
    private void updateProduct() {
        if (selectedProductId == -1) {
            showWarning("Please select a product to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            String supplierStr = (String) cmbSupplier.getSelectedItem();
            int supplierId = Integer.parseInt(supplierStr.split(" - ")[0]);
            
            FeedProduct product = new FeedProduct();
            product.setProductId(selectedProductId);
            product.setSupplierId(supplierId);
            product.setProductName(txtProductName.getText().trim());
            product.setFeedType((String) cmbFeedType.getSelectedItem());
            product.setLivestockType((String) cmbLivestockType.getSelectedItem());
            product.setPricePerKg(Double.parseDouble(txtPricePerKg.getText().trim()));
            product.setStockQuantity(Integer.parseInt(txtStockQuantity.getText().trim()));
            product.setProteinContent(Double.parseDouble(txtProteinContent.getText().trim()));
            product.setManufacturer(txtManufacturer.getText().trim());
            product.setDescription("");
            product.setStatus("AVAILABLE");
            
            boolean success = productDAO.updateProduct(product);
            
            if (success) {
                showSuccess("✅ Product updated successfully!");
                loadProducts();
                clearFields();
            } else {
                showError("Failed to update product!");
            }
            
        } catch (SQLException e) {
            showError("Error updating product: " + e.getMessage());
        }
    }
    
    // Delete product
    private void deleteProduct() {
        if (selectedProductId == -1) {
            showWarning("Please select a product to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this product?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = productDAO.deleteProduct(selectedProductId);
                
                if (success) {
                    showSuccess("✅ Product deleted successfully!");
                    loadProducts();
                    clearFields();
                } else {
                    showError("Failed to delete product!");
                }
                
            } catch (SQLException e) {
                showError("Error deleting product: " + e.getMessage());
            }
        }
    }
    
    // Search products
    private void searchProducts() {
        String searchTerm = txtSearch.getText().trim();
        
        if (searchTerm.isEmpty()) {
            loadProducts();
            return;
        }
        
        try {
            tableModel.setRowCount(0);
            List<FeedProduct> products = productDAO.searchProducts(searchTerm);
            
            for (FeedProduct product : products) {
                Object[] row = {
                    product.getProductId(),
                    product.getProductName(),
                    product.getSupplierName(),
                    product.getFeedType(),
                    product.getLivestockType(),
                    "Rs. " + String.format("%.2f", product.getPricePerKg()),
                    product.getStockQuantity() + " KG",
                    product.getStatus()
                };
                tableModel.addRow(row);
            }
            
            if (products.isEmpty()) {
                showInfo("No products found");
            } else {
                showInfo("Found " + products.size() + " product(s)");
            }
            
        } catch (SQLException e) {
            showError("Error searching products: " + e.getMessage());
        }
    }
    
    // Clear fields
    private void clearFields() {
        if (cmbSupplier.getItemCount() > 0) cmbSupplier.setSelectedIndex(0);
        txtProductName.setText("");
        cmbFeedType.setSelectedIndex(0);
        cmbLivestockType.setSelectedIndex(0);
        txtPricePerKg.setText("");
        txtStockQuantity.setText("");
        txtProteinContent.setText("");
        txtManufacturer.setText("");
        txtSearch.setText("");
        selectedProductId = -1;
        tblProducts.clearSelection();
    }
    
    // Validate inputs
    private boolean validateInputs() {
        if (cmbSupplier.getSelectedItem() == null) {
            showWarning("Please select a supplier!");
            return false;
        }
        
        if (Validator.isEmpty(txtProductName.getText())) {
            showWarning("Product name is required!");
            txtProductName.requestFocus();
            return false;
        }
        
        try {
            double price = Double.parseDouble(txtPricePerKg.getText().trim());
            if (!Validator.isPositiveNumber(price)) {
                showWarning("Price must be positive!");
                txtPricePerKg.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid price!");
            txtPricePerKg.requestFocus();
            return false;
        }
        
        try {
            int stock = Integer.parseInt(txtStockQuantity.getText().trim());
            if (stock < 0) {
                showWarning("Stock cannot be negative!");
                txtStockQuantity.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid stock quantity!");
            txtStockQuantity.requestFocus();
            return false;
        }
        
        return true;
    }
    
    // Message dialogs
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new ProductForm().setVisible(true));
    }
}