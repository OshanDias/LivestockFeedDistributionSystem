package com.feedsystem.view;

import com.feedsystem.dao.FeedSupplierDAO;
import com.feedsystem.model.FeedSupplier;
import com.feedsystem.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Supplier Management Form - TOP-BOTTOM LAYOUT (FIXED)
 */
public class SupplierForm extends JFrame {
    
    private FeedSupplierDAO supplierDAO;
    private DefaultTableModel tableModel;
    
    // Components
    private JTable tblSuppliers;
    private JTextField txtCompanyName;
    private JTextField txtContactPerson;
    private JTextField txtEmail;
    private JTextField txtPhone;
    private JTextField txtAddress;
    private JTextField txtCity;
    private JTextField txtRegNumber;
    private JTextField txtRating;
    private JTextField txtSearch;
    
    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;
    private JButton btnSearch;
    private JButton btnRefresh;
    private JButton btnBack;
    
    private int selectedSupplierId = -1;
    
    public SupplierForm() {
        supplierDAO = new FeedSupplierDAO();
        initComponents();
        loadSuppliers();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings
        setTitle("Supplier Management");
        setSize(1400, 850);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(250, 245, 255));
        
        // Header Panel - Purple
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(142, 68, 173));
        headerPanel.setBounds(0, 0, 1400, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel(" SUPPLIER MANAGEMENT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 400, 30);
        headerPanel.add(lblTitle);
        
        // Back Button
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setBounds(1250, 15, 120, 32);
        btnBack.setBackground(new Color(231, 76, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // TOP SECTION - INPUT FORM (2 COLUMNS) - INCREASED HEIGHT
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);
        inputPanel.setBackground(Color.WHITE);
        inputPanel.setBounds(20, 80, 1360, 360);
        inputPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(142, 68, 173), 2),
            "Supplier Information",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(103, 58, 183)
        ));
        add(inputPanel);
        
        // COLUMN 1 (Left)
        int col1X = 30;
        int yPos = 40;
        int gap = 70;
        
        addLabel(inputPanel, "Company Name:", col1X, yPos);
        txtCompanyName = addTextField(inputPanel, col1X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Email:", col1X, yPos);
        txtEmail = addTextField(inputPanel, col1X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "City:", col1X, yPos);
        txtCity = addTextField(inputPanel, col1X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Address:", col1X, yPos);
        txtAddress = addTextField(inputPanel, col1X, yPos + 25, 580);
        
        // COLUMN 2 (Right)
        int col2X = 680;
        yPos = 40;
        
        addLabel(inputPanel, "Contact Person:", col2X, yPos);
        txtContactPerson = addTextField(inputPanel, col2X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Phone:", col2X, yPos);
        txtPhone = addTextField(inputPanel, col2X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Registration Number:", col2X, yPos);
        txtRegNumber = addTextField(inputPanel, col2X, yPos + 25, 580);
        
        yPos += gap;
        addLabel(inputPanel, "Rating (0.0 - 5.0):", col2X, yPos);
        txtRating = addTextField(inputPanel, col2X, yPos + 25, 580);
        txtRating.setText("0.0");
        
        // Action Buttons - FIXED POSITION
        int btnY = 310;
        int btnStartX = 350;
        
        btnAdd = createButton(" ADD", btnStartX, btnY, new Color(46, 204, 113), 145);
        btnAdd.addActionListener(e -> addSupplier());
        inputPanel.add(btnAdd);
        
        btnUpdate = createButton(" UPDATE", btnStartX + 160, btnY, new Color(142, 68, 173), 145);
        btnUpdate.addActionListener(e -> updateSupplier());
        inputPanel.add(btnUpdate);
        
        btnDelete = createButton("🗑️ DELETE", btnStartX + 320, btnY, new Color(231, 76, 60), 150);
        btnDelete.addActionListener(e -> deleteSupplier());
        inputPanel.add(btnDelete);
        
        btnClear = createButton(" CLEAR", btnStartX + 480, btnY, new Color(149, 165, 166), 145);
        btnClear.addActionListener(e -> clearFields());
        inputPanel.add(btnClear);
        
        // BOTTOM SECTION - TABLE (FULL WIDTH) - ADJUSTED POSITION
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(null);
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBounds(20, 460, 1360, 370);
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(142, 68, 173), 2),
            "Supplier Records",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(103, 58, 183)
        ));
        add(tablePanel);
        
        // Search Bar - Horizontal
        JLabel lblSearch = new JLabel(" Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSearch.setBounds(30, 35, 100, 35);
        tablePanel.add(lblSearch);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBounds(130, 35, 900, 35);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        tablePanel.add(txtSearch);
        
        btnSearch = createButton("SEARCH", 1050, 35, new Color(142, 68, 173), 130);
        btnSearch.addActionListener(e -> searchSuppliers());
        tablePanel.add(btnSearch);
        
        btnRefresh = createButton("REFRESH", 1195, 35, new Color(155, 89, 182), 130);
        btnRefresh.addActionListener(e -> loadSuppliers());
        tablePanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "Company Name", "Contact Person", "Email", "Phone", "City", "Reg Number", "Rating"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblSuppliers = new JTable(tableModel);
        tblSuppliers.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tblSuppliers.setRowHeight(28);
        tblSuppliers.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tblSuppliers.getTableHeader().setBackground(new Color(142, 68, 173));
        tblSuppliers.getTableHeader().setForeground(Color.WHITE);
        tblSuppliers.getTableHeader().setPreferredSize(new Dimension(0, 32));
        tblSuppliers.setSelectionBackground(new Color(155, 89, 182));
        tblSuppliers.setSelectionForeground(Color.WHITE);
        tblSuppliers.setGridColor(new Color(220, 220, 220));
        
        // Table selection listener
        tblSuppliers.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedSupplier();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblSuppliers);
        scrollPane.setBounds(30, 85, 1300, 270);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(155, 89, 182), 1));
        tablePanel.add(scrollPane);
    }
    
    // Helper methods
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(new Color(103, 58, 183));
        label.setBounds(x, y, 300, 20);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBounds(x, y, width, 35);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, width, 38);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    // Load all suppliers
    private void loadSuppliers() {
        try {
            tableModel.setRowCount(0);
            List<FeedSupplier> suppliers = supplierDAO.getAllSuppliers();
            
            for (FeedSupplier supplier : suppliers) {
                Object[] row = {
                    supplier.getSupplierId(),
                    supplier.getCompanyName(),
                    supplier.getContactPerson(),
                    supplier.getEmail(),
                    supplier.getPhone(),
                    supplier.getCity(),
                    supplier.getRegistrationNumber(),
                    String.format("⭐ %.1f", supplier.getRating())
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading suppliers: " + e.getMessage());
        }
    }
    
    // Load selected supplier into fields
    private void loadSelectedSupplier() {
        int selectedRow = tblSuppliers.getSelectedRow();
        if (selectedRow >= 0) {
            selectedSupplierId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                FeedSupplier supplier = supplierDAO.getSupplierById(selectedSupplierId);
                if (supplier != null) {
                    txtCompanyName.setText(supplier.getCompanyName());
                    txtContactPerson.setText(supplier.getContactPerson());
                    txtEmail.setText(supplier.getEmail());
                    txtPhone.setText(supplier.getPhone());
                    txtCity.setText(supplier.getCity());
                    txtRegNumber.setText(supplier.getRegistrationNumber());
                    txtRating.setText(String.format("%.1f", supplier.getRating()));
                    txtAddress.setText(supplier.getAddress());
                }
            } catch (SQLException e) {
                showError("Error loading supplier details: " + e.getMessage());
            }
        }
    }
    
    // Add supplier
    private void addSupplier() {
        if (!validateInputs()) return;
        
        try {
            FeedSupplier supplier = new FeedSupplier();
            supplier.setCompanyName(txtCompanyName.getText().trim());
            supplier.setContactPerson(txtContactPerson.getText().trim());
            supplier.setEmail(txtEmail.getText().trim());
            supplier.setPhone(txtPhone.getText().trim());
            supplier.setCity(txtCity.getText().trim());
            supplier.setRegistrationNumber(txtRegNumber.getText().trim().toUpperCase());
            supplier.setRating(Double.parseDouble(txtRating.getText().trim()));
            supplier.setAddress(txtAddress.getText().trim());
            
            boolean success = supplierDAO.addSupplier(supplier);
            
            if (success) {
                showSuccess("✅ Supplier added successfully!");
                loadSuppliers();
                clearFields();
            } else {
                showError("Failed to add supplier!");
            }
            
        } catch (SQLException e) {
            showError("Error adding supplier: " + e.getMessage());
        }
    }
    
    // Update supplier
    private void updateSupplier() {
        if (selectedSupplierId == -1) {
            showWarning("Please select a supplier to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            FeedSupplier supplier = new FeedSupplier();
            supplier.setSupplierId(selectedSupplierId);
            supplier.setCompanyName(txtCompanyName.getText().trim());
            supplier.setContactPerson(txtContactPerson.getText().trim());
            supplier.setEmail(txtEmail.getText().trim());
            supplier.setPhone(txtPhone.getText().trim());
            supplier.setCity(txtCity.getText().trim());
            supplier.setRegistrationNumber(txtRegNumber.getText().trim().toUpperCase());
            supplier.setRating(Double.parseDouble(txtRating.getText().trim()));
            supplier.setAddress(txtAddress.getText().trim());
            
            boolean success = supplierDAO.updateSupplier(supplier);
            
            if (success) {
                showSuccess("✅ Supplier updated successfully!");
                loadSuppliers();
                clearFields();
            } else {
                showError("Failed to update supplier!");
            }
            
        } catch (SQLException e) {
            showError("Error updating supplier: " + e.getMessage());
        }
    }
    
    // Delete supplier
    private void deleteSupplier() {
        if (selectedSupplierId == -1) {
            showWarning("Please select a supplier to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this supplier?\n\nCompany: " + txtCompanyName.getText(),
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = supplierDAO.deleteSupplier(selectedSupplierId);
                
                if (success) {
                    showSuccess("✅ Supplier deleted successfully!");
                    loadSuppliers();
                    clearFields();
                } else {
                    showError("Failed to delete supplier!");
                }
                
            } catch (SQLException e) {
                showError("Error deleting supplier: " + e.getMessage());
            }
        }
    }
    
    // Search suppliers
    private void searchSuppliers() {
        String searchTerm = txtSearch.getText().trim();
        
        if (searchTerm.isEmpty()) {
            loadSuppliers();
            return;
        }
        
        try {
            tableModel.setRowCount(0);
            List<FeedSupplier> suppliers = supplierDAO.searchSuppliers(searchTerm);
            
            for (FeedSupplier supplier : suppliers) {
                Object[] row = {
                    supplier.getSupplierId(),
                    supplier.getCompanyName(),
                    supplier.getContactPerson(),
                    supplier.getEmail(),
                    supplier.getPhone(),
                    supplier.getCity(),
                    supplier.getRegistrationNumber(),
                    String.format("⭐ %.1f", supplier.getRating())
                };
                tableModel.addRow(row);
            }
            
            if (suppliers.isEmpty()) {
                showInfo("No suppliers found matching: " + searchTerm);
            } else {
                showInfo("Found " + suppliers.size() + " supplier(s)");
            }
            
        } catch (SQLException e) {
            showError("Error searching suppliers: " + e.getMessage());
        }
    }
    
    // Clear all fields
    private void clearFields() {
        txtCompanyName.setText("");
        txtContactPerson.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtCity.setText("");
        txtRegNumber.setText("");
        txtRating.setText("0.0");
        txtAddress.setText("");
        txtSearch.setText("");
        selectedSupplierId = -1;
        tblSuppliers.clearSelection();
    }
    
    // Validate inputs
    private boolean validateInputs() {
        if (Validator.isEmpty(txtCompanyName.getText())) {
            showWarning("Company name is required!");
            txtCompanyName.requestFocus();
            return false;
        }
        
        if (Validator.isEmpty(txtContactPerson.getText())) {
            showWarning("Contact person is required!");
            txtContactPerson.requestFocus();
            return false;
        }
        
        String email = txtEmail.getText().trim();
        if (!Validator.isValidEmail(email)) {
            showWarning("Invalid email format!");
            txtEmail.requestFocus();
            return false;
        }
        
        String phone = txtPhone.getText().trim();
        if (!Validator.isValidPhone(phone)) {
            showWarning("Invalid phone number! (Format: 0xxxxxxxxx)");
            txtPhone.requestFocus();
            return false;
        }
        
        try {
            double rating = Double.parseDouble(txtRating.getText().trim());
            if (!Validator.isValidRating(rating)) {
                showWarning("Rating must be between 0.0 and 5.0!");
                txtRating.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid rating value!");
            txtRating.requestFocus();
            return false;
        }
        
        return true;
    }
    
    // Message dialogs
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new SupplierForm().setVisible(true));
    }
}