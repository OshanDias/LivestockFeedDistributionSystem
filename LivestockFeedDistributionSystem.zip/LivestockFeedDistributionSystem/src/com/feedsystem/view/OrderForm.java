package com.feedsystem.view;

import com.feedsystem.dao.*;
import com.feedsystem.model.*;
import com.feedsystem.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * Order Management Form - MAIN TRANSACTION - TOP-BOTTOM LAYOUT
 */
public class OrderForm extends JFrame {
    
    private FeedOrderDAO orderDAO;
    private LivestockFarmerDAO farmerDAO;
    private FeedProductDAO productDAO;
    private DefaultTableModel tableModel;
    
    // Components
    private JTable tblOrders;
    private JComboBox<String> cmbFarmer;
    private JComboBox<String> cmbProduct;
    private JTextField txtOrderDate;
    private JTextField txtDeliveryDate;
    private JTextField txtQuantityKg;
    private JTextField txtPricePerKg;
    private JTextField txtTotalAmount;
    private JTextField txtDeliveryAddress;
    private JComboBox<String> cmbPaymentStatus;
    private JComboBox<String> cmbDeliveryStatus;
    private JTextArea txtNotes;
    private JTextField txtSearch;
    
    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnCalculate;
    private JButton btnClear;
    private JButton btnShowAll;
    private JButton btnShowProcessing;
    private JButton btnRefresh;
    private JButton btnBack;
    
    private int selectedOrderId = -1;
    
    public OrderForm() {
        orderDAO = new FeedOrderDAO();
        farmerDAO = new LivestockFarmerDAO();
        productDAO = new FeedProductDAO();
        initComponents();
        loadOrders();
        loadFarmers();
        loadProducts();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings
        setTitle("Order Management - Main Transaction");
        setSize(1400, 850);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(250, 245, 255));
        
        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(142, 68, 173));
        headerPanel.setBounds(0, 0, 1400, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel(" ORDER MANAGEMENT - BOOKING SYSTEM");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 700, 30);
        headerPanel.add(lblTitle);
        
        // Back Button
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setBounds(1250, 15, 120, 32);
        btnBack.setBackground(new Color(231, 76, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // TOP SECTION - INPUT FORM
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);
        inputPanel.setBackground(Color.WHITE);
        inputPanel.setBounds(20, 80, 1360, 360);
        inputPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(142, 68, 173), 2),
            "Order Information",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(103, 58, 183)
        ));
        add(inputPanel);
        
        // COLUMN 1
        int col1X = 30;
        int col2X = 680;
        
        addLabel(inputPanel, "👨‍🌾 Farmer:", col1X, 40);
        cmbFarmer = new JComboBox<>();
        cmbFarmer.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbFarmer.setBounds(col1X, 65, 580, 35);
        inputPanel.add(cmbFarmer);
        
        addLabel(inputPanel, " Order Date (YYYY-MM-DD):", col1X, 110);
        txtOrderDate = addTextField(inputPanel, col1X, 135, 280);
        txtOrderDate.setText(LocalDate.now().toString());
        
        addLabel(inputPanel, "Quantity (KG):", col1X + 300, 110);
        txtQuantityKg = addTextField(inputPanel, col1X + 300, 135, 280);
        
        addLabel(inputPanel, "Price per KG (Rs):", col1X, 180);
        txtPricePerKg = addTextField(inputPanel, col1X, 205, 280);
        txtPricePerKg.setEditable(false);
        txtPricePerKg.setBackground(new Color(240, 240, 240));
        
        addLabel(inputPanel, " Total Amount (Rs):", col1X + 300, 180);
        txtTotalAmount = addTextField(inputPanel, col1X + 300, 205, 280);
        txtTotalAmount.setEditable(false);
        txtTotalAmount.setBackground(new Color(255, 255, 200));
        txtTotalAmount.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        addLabel(inputPanel, "Payment Status:", col1X, 250);
        String[] paymentStatuses = {"PENDING", "PAID", "PARTIAL"};
        cmbPaymentStatus = new JComboBox<>(paymentStatuses);
        cmbPaymentStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbPaymentStatus.setBounds(col1X, 275, 280, 35);
        inputPanel.add(cmbPaymentStatus);
        
        addLabel(inputPanel, "Notes:", col1X + 300, 250);
        txtNotes = new JTextArea();
        txtNotes.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        txtNotes.setLineWrap(true);
        txtNotes.setWrapStyleWord(true);
        txtNotes.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        JScrollPane scrollNotes = new JScrollPane(txtNotes);
        scrollNotes.setBounds(col1X + 300, 275, 280, 35);
        inputPanel.add(scrollNotes);
        
        // COLUMN 2
        addLabel(inputPanel, "🌱 Product:", col2X, 40);
        cmbProduct = new JComboBox<>();
        cmbProduct.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbProduct.setBounds(col2X, 65, 580, 35);
        cmbProduct.addActionListener(e -> updatePricePerKg());
        inputPanel.add(cmbProduct);
        
        addLabel(inputPanel, " Delivery Date (YYYY-MM-DD):", col2X, 110);
        txtDeliveryDate = addTextField(inputPanel, col2X, 135, 580);
        
        addLabel(inputPanel, "Delivery Address:", col2X, 180);
        txtDeliveryAddress = addTextField(inputPanel, col2X, 205, 580);
        
        addLabel(inputPanel, "Delivery Status:", col2X, 250);
        String[] deliveryStatuses = {"PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"};
        cmbDeliveryStatus = new JComboBox<>(deliveryStatuses);
        cmbDeliveryStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbDeliveryStatus.setBounds(col2X, 275, 580, 35);
        inputPanel.add(cmbDeliveryStatus);
        
        // Action Buttons
        int btnY = 310;
        int btnStartX = 250;
        
        btnCalculate = createButton(" CALCULATE", btnStartX, btnY, new Color(52, 152, 219), 170);
        btnCalculate.addActionListener(e -> calculateTotal());
        inputPanel.add(btnCalculate);
        
        btnAdd = createButton("➕ CREATE ORDER", btnStartX + 180, btnY, new Color(46, 204, 113), 170);
        btnAdd.addActionListener(e -> addOrder());
        inputPanel.add(btnAdd);
        
        btnUpdate = createButton(" UPDATE", btnStartX + 360, btnY, new Color(142, 68, 173), 170);
        btnUpdate.addActionListener(e -> updateOrder());
        inputPanel.add(btnUpdate);
        
        btnClear = createButton(" CLEAR", btnStartX + 540, btnY, new Color(149, 165, 166), 170);
        btnClear.addActionListener(e -> clearFields());
        inputPanel.add(btnClear);
        
        // BOTTOM SECTION - TABLE
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(null);
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBounds(20, 460, 1360, 370);
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(142, 68, 173), 2),
            "Order Records",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(103, 58, 183)
        ));
        add(tablePanel);
        
        // Filter Buttons
        JLabel lblFilter = new JLabel("Filter:");
        lblFilter.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblFilter.setBounds(30, 35, 70, 35);
        tablePanel.add(lblFilter);
        
        btnShowAll = createButton("ALL ORDERS", 110, 35, new Color(52, 152, 219), 150);
        btnShowAll.addActionListener(e -> loadOrders());
        tablePanel.add(btnShowAll);
        
        btnShowProcessing = createButton("PROCESSING", 275, 35, new Color(241, 196, 15), 150);
        btnShowProcessing.addActionListener(e -> loadProcessingOrders());
        tablePanel.add(btnShowProcessing);
        
        btnRefresh = createButton(" REFRESH", 1195, 35, new Color(155, 89, 182), 130);
        btnRefresh.addActionListener(e -> loadOrders());
        tablePanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "Farmer", "Product", "Order Date", "Delivery Date", "Quantity(KG)", "Total (Rs)", "Payment", "Delivery"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblOrders = new JTable(tableModel);
        tblOrders.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        tblOrders.setRowHeight(28);
        tblOrders.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 11));
        tblOrders.getTableHeader().setBackground(new Color(142, 68, 173));
        tblOrders.getTableHeader().setForeground(Color.WHITE);
        tblOrders.getTableHeader().setPreferredSize(new Dimension(0, 32));
        tblOrders.setSelectionBackground(new Color(155, 89, 182));
        tblOrders.setSelectionForeground(Color.WHITE);
        tblOrders.setGridColor(new Color(220, 220, 220));
        
        tblOrders.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedOrder();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblOrders);
        scrollPane.setBounds(30, 85, 1300, 270);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(155, 89, 182), 1));
        tablePanel.add(scrollPane);
    }
    
    // Helper methods
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(new Color(103, 58, 183));
        label.setBounds(x, y, 300, 20);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBounds(x, y, width, 35);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btn.setBounds(x, y, width, 38);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    // Load farmers
    private void loadFarmers() {
        try {
            cmbFarmer.removeAllItems();
            List<LivestockFarmer> farmers = farmerDAO.getAllFarmers();
            for (LivestockFarmer farmer : farmers) {
                cmbFarmer.addItem(farmer.getFarmerId() + " - " + farmer.getFullName() + 
                                 " (" + farmer.getLivestockType() + ")");
            }
        } catch (SQLException e) {
            showError("Error loading farmers: " + e.getMessage());
        }
    }
    
    // Load products
    private void loadProducts() {
        try {
            cmbProduct.removeAllItems();
            List<FeedProduct> products = productDAO.getAvailableProducts();
            for (FeedProduct product : products) {
                cmbProduct.addItem(product.getProductId() + " - " + product.getProductName() + 
                                  " (" + product.getFeedType() + ") - Rs." + 
                                  String.format("%.2f", product.getPricePerKg()) + "/kg");
            }
        } catch (SQLException e) {
            showError("Error loading products: " + e.getMessage());
        }
    }
    
    // Update price when product selected
    private void updatePricePerKg() {
        String selected = (String) cmbProduct.getSelectedItem();
        if (selected != null) {
            try {
                int productId = Integer.parseInt(selected.split(" - ")[0]);
                FeedProduct product = productDAO.getProductById(productId);
                if (product != null) {
                    txtPricePerKg.setText(String.format("%.2f", product.getPricePerKg()));
                }
            } catch (Exception e) {
                // Ignore
            }
        }
    }
    
    // Calculate total
    private void calculateTotal() {
        try {
            int quantity = Integer.parseInt(txtQuantityKg.getText().trim());
            double pricePerKg = Double.parseDouble(txtPricePerKg.getText().trim());
            
            double total = quantity * pricePerKg;
            txtTotalAmount.setText(String.format("%.2f", total));
            
            showInfo("✅ Total calculated: Rs." + String.format("%.2f", total));
            
        } catch (NumberFormatException e) {
            showWarning("Please enter valid quantity and price!");
        }
    }
    
    // Load all orders
    private void loadOrders() {
        try {
            tableModel.setRowCount(0);
            List<FeedOrder> orders = orderDAO.getAllOrders();
            
            for (FeedOrder order : orders) {
                Object[] row = {
                    order.getOrderId(),
                    order.getFarmerName(),
                    order.getProductName(),
                    order.getOrderDate(),
                    order.getDeliveryDate(),
                    order.getQuantityKg() + " KG",
                    "Rs. " + String.format("%.2f", order.getTotalAmount()),
                    order.getPaymentStatus(),
                    order.getDeliveryStatus()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading orders: " + e.getMessage());
        }
    }
    
    // Load processing orders
    private void loadProcessingOrders() {
        try {
            tableModel.setRowCount(0);
            List<FeedOrder> orders = orderDAO.getPendingOrders();
            
            for (FeedOrder order : orders) {
                Object[] row = {
                    order.getOrderId(),
                    order.getFarmerName(),
                    order.getProductName(),
                    order.getOrderDate(),
                    order.getDeliveryDate(),
                    order.getQuantityKg() + " KG",
                    "Rs. " + String.format("%.2f", order.getTotalAmount()),
                    order.getPaymentStatus(),
                    order.getDeliveryStatus()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading processing orders: " + e.getMessage());
        }
    }
    
    // Load selected order
    private void loadSelectedOrder() {
        int selectedRow = tblOrders.getSelectedRow();
        if (selectedRow >= 0) {
            selectedOrderId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                FeedOrder order = orderDAO.getOrderById(selectedOrderId);
                if (order != null) {
                    txtOrderDate.setText(order.getOrderDate().toString());
                    txtDeliveryDate.setText(order.getDeliveryDate().toString());
                    txtQuantityKg.setText(String.valueOf(order.getQuantityKg()));
                    txtPricePerKg.setText(String.format("%.2f", order.getPricePerKg()));
                    txtTotalAmount.setText(String.format("%.2f", order.getTotalAmount()));
                    txtDeliveryAddress.setText(order.getDeliveryAddress());
                    cmbPaymentStatus.setSelectedItem(order.getPaymentStatus());
                    cmbDeliveryStatus.setSelectedItem(order.getDeliveryStatus());
                    txtNotes.setText(order.getNotes());
                }
            } catch (SQLException e) {
                showError("Error loading order details: " + e.getMessage());
            }
        }
    }
    
    // Add order
    private void addOrder() {
        if (!validateInputs()) return;
        
        try {
            String farmerStr = (String) cmbFarmer.getSelectedItem();
            int farmerId = Integer.parseInt(farmerStr.split(" - ")[0]);
            
            String productStr = (String) cmbProduct.getSelectedItem();
            int productId = Integer.parseInt(productStr.split(" - ")[0]);
            
            FeedOrder order = new FeedOrder();
            order.setFarmerId(farmerId);
            order.setProductId(productId);
            order.setOrderDate(Date.valueOf(txtOrderDate.getText().trim()));
            order.setDeliveryDate(Date.valueOf(txtDeliveryDate.getText().trim()));
            order.setQuantityKg(Integer.parseInt(txtQuantityKg.getText().trim()));
            order.setPricePerKg(Double.parseDouble(txtPricePerKg.getText().trim()));
            order.setTotalAmount(Double.parseDouble(txtTotalAmount.getText().trim()));
            order.setDeliveryAddress(txtDeliveryAddress.getText().trim());
            order.setPaymentStatus((String) cmbPaymentStatus.getSelectedItem());
            order.setDeliveryStatus((String) cmbDeliveryStatus.getSelectedItem());
            order.setNotes(txtNotes.getText().trim());
            
            boolean success = orderDAO.addOrder(order);
            
            if (success) {
                // Reduce stock
                int quantity = Integer.parseInt(txtQuantityKg.getText().trim());
                productDAO.reduceStock(productId, quantity);
                
                showSuccess("✅ Order created successfully!\n\nTotal: Rs." + txtTotalAmount.getText());
                loadOrders();
                loadProducts(); // Refresh product list
                clearFields();
            } else {
                showError("Failed to create order!");
            }
            
        } catch (SQLException e) {
            showError("Error creating order: " + e.getMessage());
        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    // Update order
    private void updateOrder() {
        if (selectedOrderId == -1) {
            showWarning("Please select an order to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            String farmerStr = (String) cmbFarmer.getSelectedItem();
            int farmerId = Integer.parseInt(farmerStr.split(" - ")[0]);
            
            String productStr = (String) cmbProduct.getSelectedItem();
            int productId = Integer.parseInt(productStr.split(" - ")[0]);
            
            FeedOrder order = new FeedOrder();
            order.setOrderId(selectedOrderId);
            order.setFarmerId(farmerId);
            order.setProductId(productId);
            order.setOrderDate(Date.valueOf(txtOrderDate.getText().trim()));
            order.setDeliveryDate(Date.valueOf(txtDeliveryDate.getText().trim()));
            order.setQuantityKg(Integer.parseInt(txtQuantityKg.getText().trim()));
            order.setPricePerKg(Double.parseDouble(txtPricePerKg.getText().trim()));
            order.setTotalAmount(Double.parseDouble(txtTotalAmount.getText().trim()));
            order.setDeliveryAddress(txtDeliveryAddress.getText().trim());
            order.setPaymentStatus((String) cmbPaymentStatus.getSelectedItem());
            order.setDeliveryStatus((String) cmbDeliveryStatus.getSelectedItem());
            order.setNotes(txtNotes.getText().trim());
            
            boolean success = orderDAO.updateOrder(order);
            
            if (success) {
                showSuccess("✅ Order updated successfully!");
                loadOrders();
                clearFields();
            } else {
                showError("Failed to update order!");
            }
            
        } catch (SQLException e) {
            showError("Error updating order: " + e.getMessage());
        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }
    
    // Clear fields
    private void clearFields() {
        if (cmbFarmer.getItemCount() > 0) cmbFarmer.setSelectedIndex(0);
        if (cmbProduct.getItemCount() > 0) cmbProduct.setSelectedIndex(0);
        txtOrderDate.setText(LocalDate.now().toString());
        txtDeliveryDate.setText("");
        txtQuantityKg.setText("");
        txtPricePerKg.setText("");
        txtTotalAmount.setText("");
        txtDeliveryAddress.setText("");
        cmbPaymentStatus.setSelectedIndex(0);
        cmbDeliveryStatus.setSelectedIndex(0);
        txtNotes.setText("");
        selectedOrderId = -1;
        tblOrders.clearSelection();
    }
    
    // Validate inputs
    private boolean validateInputs() {
        if (cmbFarmer.getSelectedItem() == null) {
            showWarning("Please select a farmer!");
            return false;
        }
        
        if (cmbProduct.getSelectedItem() == null) {
            showWarning("Please select a product!");
            return false;
        }
        
        if (Validator.isEmpty(txtTotalAmount.getText())) {
            showWarning("Please calculate total first!");
            btnCalculate.requestFocus();
            return false;
        }
        
        try {
            Date.valueOf(txtOrderDate.getText().trim());
        } catch (Exception e) {
            showWarning("Invalid order date format! (YYYY-MM-DD)");
            txtOrderDate.requestFocus();
            return false;
        }
        
        try {
            Date.valueOf(txtDeliveryDate.getText().trim());
        } catch (Exception e) {
            showWarning("Invalid delivery date format! (YYYY-MM-DD)");
            txtDeliveryDate.requestFocus();
            return false;
        }
        
        return true;
    }
    
    // Message dialogs
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new OrderForm().setVisible(true));
    }
}