package com.feedsystem.view;

import com.feedsystem.dao.LivestockFarmerDAO;
import com.feedsystem.model.LivestockFarmer;
import com.feedsystem.util.Validator;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Farmer Management Form - TOP-BOTTOM LAYOUT
 */
public class FarmerForm extends JFrame {
    
    private LivestockFarmerDAO farmerDAO;
    private DefaultTableModel tableModel;
    
    // Components
    private JTable tblFarmers;
    private JTextField txtFirstName;
    private JTextField txtLastName;
    private JTextField txtEmail;
    private JTextField txtPhone;
    private JTextField txtNic;
    private JTextField txtAddress;
    private JTextField txtFarmLocation;
    private JTextField txtFarmSize;
    private JComboBox<String> cmbLivestockType;
    private JTextField txtLivestockCount;
    private JTextField txtSearch;
    
    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;
    private JButton btnSearch;
    private JButton btnRefresh;
    private JButton btnBack;
    
    private int selectedFarmerId = -1;
    
    public FarmerForm() {
        farmerDAO = new LivestockFarmerDAO();
        initComponents();
        loadFarmers();
        setLocationRelativeTo(null);
    }
    
    private void initComponents() {
        // Frame settings
        setTitle("Farmer Management");
        setSize(1400, 850);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(250, 245, 255));
        
        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBackground(new Color(142, 68, 173));
        headerPanel.setBounds(0, 0, 1400, 60);
        add(headerPanel);
        
        JLabel lblTitle = new JLabel("Farmer Managment");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(30, 15, 400, 30);
        headerPanel.add(lblTitle);
        
        // Back Button
        btnBack = new JButton("← BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setBounds(1250, 15, 120, 32);
        btnBack.setBackground(new Color(231, 76, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.addActionListener(e -> dispose());
        headerPanel.add(btnBack);
        
        // TOP SECTION - INPUT FORM - FIXED
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);
        inputPanel.setBackground(Color.WHITE);
        inputPanel.setBounds(20, 80, 1360, 360);
        inputPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(142, 68, 173), 2),
            "Farmer Information",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(103, 58, 183)
        ));
        add(inputPanel);
        
        // ROW 1
        int col1X = 30;
        int col2X = 680;
        
        addLabel(inputPanel, "First Name:", col1X, 40);
        txtFirstName = addTextField(inputPanel, col1X, 65, 580);
        
        addLabel(inputPanel, "Last Name:", col2X, 40);
        txtLastName = addTextField(inputPanel, col2X, 65, 580);
        
        // ROW 2
        addLabel(inputPanel, "Email:", col1X, 110);
        txtEmail = addTextField(inputPanel, col1X, 135, 580);
        
        addLabel(inputPanel, "Phone:", col2X, 110);
        txtPhone = addTextField(inputPanel, col2X, 135, 580);
        
        // ROW 3
        addLabel(inputPanel, "NIC:", col1X, 180);
        txtNic = addTextField(inputPanel, col1X, 205, 580);
        
        addLabel(inputPanel, "Address:", col2X, 180);
        txtAddress = addTextField(inputPanel, col2X, 205, 580);
        
        // ROW 4
        addLabel(inputPanel, "Farm Location:", col1X, 250);
        txtFarmLocation = addTextField(inputPanel, col1X, 275, 360);
        
        addLabel(inputPanel, "Farm Size (acres):", col1X + 380, 250);
        txtFarmSize = addTextField(inputPanel, col1X + 380, 275, 200);
        
        addLabel(inputPanel, "Livestock Type:", col2X, 250);
        String[] livestockTypes = {"Cattle", "Poultry", "Goat", "Sheep", "Pig", "Mixed"};
        cmbLivestockType = new JComboBox<>(livestockTypes);
        cmbLivestockType.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbLivestockType.setBounds(col2X, 275, 360, 35);
        inputPanel.add(cmbLivestockType);
        
        addLabel(inputPanel, "Livestock Count:", col2X + 380, 250);
        txtLivestockCount = addTextField(inputPanel, col2X + 380, 275, 200);
        
        // Action Buttons - PROPER SPACING
        int btnY = 310;
        int btnStartX = 350;
        
        btnAdd = createButton(" ADD", btnStartX, btnY, new Color(46, 204, 113), 150);
        btnAdd.addActionListener(e -> addFarmer());
        inputPanel.add(btnAdd);
        
        btnUpdate = createButton(" UPDATE", btnStartX + 160, btnY, new Color(142, 68, 173), 150);
        btnUpdate.addActionListener(e -> updateFarmer());
        inputPanel.add(btnUpdate);
        
        btnDelete = createButton("🗑️ DELETE", btnStartX + 320, btnY, new Color(231, 76, 60), 150);
        btnDelete.addActionListener(e -> deleteFarmer());
        inputPanel.add(btnDelete);
        
        btnClear = createButton(" CLEAR", btnStartX + 480, btnY, new Color(149, 165, 166), 150);
        btnClear.addActionListener(e -> clearFields());
        inputPanel.add(btnClear);
        
        // BOTTOM SECTION - TABLE
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(null);
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBounds(20, 460, 1360, 370);
        tablePanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(142, 68, 173), 2),
            "Farmer Records",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(103, 58, 183)
        ));
        add(tablePanel);
        
        // Search Bar
        JLabel lblSearch = new JLabel(" Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSearch.setBounds(30, 35, 100, 35);
        tablePanel.add(lblSearch);
        
        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBounds(130, 35, 900, 35);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        tablePanel.add(txtSearch);
        
        btnSearch = createButton("SEARCH", 1050, 35, new Color(142, 68, 173), 130);
        btnSearch.addActionListener(e -> searchFarmers());
        tablePanel.add(btnSearch);
        
        btnRefresh = createButton("REFRESH", 1195, 35, new Color(155, 89, 182), 130);
        btnRefresh.addActionListener(e -> loadFarmers());
        tablePanel.add(btnRefresh);
        
        // Table
        String[] columns = {"ID", "First Name", "Last Name", "Email", "Phone", "NIC", "Location", "Livestock", "Count"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tblFarmers = new JTable(tableModel);
        tblFarmers.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tblFarmers.setRowHeight(28);
        tblFarmers.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tblFarmers.getTableHeader().setBackground(new Color(142, 68, 173));
        tblFarmers.getTableHeader().setForeground(Color.WHITE);
        tblFarmers.getTableHeader().setPreferredSize(new Dimension(0, 32));
        tblFarmers.setSelectionBackground(new Color(155, 89, 182));
        tblFarmers.setSelectionForeground(Color.WHITE);
        tblFarmers.setGridColor(new Color(220, 220, 220));
        
        tblFarmers.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedFarmer();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tblFarmers);
        scrollPane.setBounds(30, 85, 1300, 270);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(155, 89, 182), 1));
        tablePanel.add(scrollPane);
    }
    
    // Helper methods
    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(new Color(103, 58, 183));
        label.setBounds(x, y, 300, 20);
        panel.add(label);
    }
    
    private JTextField addTextField(JPanel panel, int x, int y, int width) {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBounds(x, y, width, 35);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(155, 89, 182), 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        panel.add(field);
        return field;
    }
    
    private JButton createButton(String text, int x, int y, Color color, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBounds(x, y, width, 38);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        
        return btn;
    }
    
    // Load all farmers
    private void loadFarmers() {
        try {
            tableModel.setRowCount(0);
            List<LivestockFarmer> farmers = farmerDAO.getAllFarmers();
            
            for (LivestockFarmer farmer : farmers) {
                Object[] row = {
                    farmer.getFarmerId(),
                    farmer.getFirstName(),
                    farmer.getLastName(),
                    farmer.getEmail(),
                    farmer.getPhone(),
                    farmer.getNic(),
                    farmer.getFarmLocation(),
                    farmer.getLivestockType(),
                    farmer.getLivestockCount()
                };
                tableModel.addRow(row);
            }
            
        } catch (SQLException e) {
            showError("Error loading farmers: " + e.getMessage());
        }
    }
    
    // Load selected farmer
    private void loadSelectedFarmer() {
        int selectedRow = tblFarmers.getSelectedRow();
        if (selectedRow >= 0) {
            selectedFarmerId = (int) tableModel.getValueAt(selectedRow, 0);
            
            try {
                LivestockFarmer farmer = farmerDAO.getFarmerById(selectedFarmerId);
                if (farmer != null) {
                    txtFirstName.setText(farmer.getFirstName());
                    txtLastName.setText(farmer.getLastName());
                    txtEmail.setText(farmer.getEmail());
                    txtPhone.setText(farmer.getPhone());
                    txtNic.setText(farmer.getNic());
                    txtAddress.setText(farmer.getAddress());
                    txtFarmLocation.setText(farmer.getFarmLocation());
                    txtFarmSize.setText(String.format("%.2f", farmer.getFarmSize()));
                    cmbLivestockType.setSelectedItem(farmer.getLivestockType());
                    txtLivestockCount.setText(String.valueOf(farmer.getLivestockCount()));
                }
            } catch (SQLException e) {
                showError("Error loading farmer details: " + e.getMessage());
            }
        }
    }
    
    // Add farmer
    private void addFarmer() {
        if (!validateInputs()) return;
        
        try {
            LivestockFarmer farmer = new LivestockFarmer();
            farmer.setFirstName(txtFirstName.getText().trim());
            farmer.setLastName(txtLastName.getText().trim());
            farmer.setEmail(txtEmail.getText().trim());
            farmer.setPhone(txtPhone.getText().trim());
            farmer.setNic(txtNic.getText().trim());
            farmer.setAddress(txtAddress.getText().trim());
            farmer.setFarmLocation(txtFarmLocation.getText().trim());
            farmer.setFarmSize(Double.parseDouble(txtFarmSize.getText().trim()));
            farmer.setLivestockType((String) cmbLivestockType.getSelectedItem());
            farmer.setLivestockCount(Integer.parseInt(txtLivestockCount.getText().trim()));
            
            boolean success = farmerDAO.addFarmer(farmer);
            
            if (success) {
                showSuccess("✅ Farmer added successfully!");
                loadFarmers();
                clearFields();
            } else {
                showError("Failed to add farmer!");
            }
            
        } catch (SQLException e) {
            showError("Error adding farmer: " + e.getMessage());
        }
    }
    
    // Update farmer
    private void updateFarmer() {
        if (selectedFarmerId == -1) {
            showWarning("Please select a farmer to update!");
            return;
        }
        
        if (!validateInputs()) return;
        
        try {
            LivestockFarmer farmer = new LivestockFarmer();
            farmer.setFarmerId(selectedFarmerId);
            farmer.setFirstName(txtFirstName.getText().trim());
            farmer.setLastName(txtLastName.getText().trim());
            farmer.setEmail(txtEmail.getText().trim());
            farmer.setPhone(txtPhone.getText().trim());
            farmer.setNic(txtNic.getText().trim());
            farmer.setAddress(txtAddress.getText().trim());
            farmer.setFarmLocation(txtFarmLocation.getText().trim());
            farmer.setFarmSize(Double.parseDouble(txtFarmSize.getText().trim()));
            farmer.setLivestockType((String) cmbLivestockType.getSelectedItem());
            farmer.setLivestockCount(Integer.parseInt(txtLivestockCount.getText().trim()));
            
            boolean success = farmerDAO.updateFarmer(farmer);
            
            if (success) {
                showSuccess("✅ Farmer updated successfully!");
                loadFarmers();
                clearFields();
            } else {
                showError("Failed to update farmer!");
            }
            
        } catch (SQLException e) {
            showError("Error updating farmer: " + e.getMessage());
        }
    }
    
    // Delete farmer
    private void deleteFarmer() {
        if (selectedFarmerId == -1) {
            showWarning("Please select a farmer to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this farmer?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = farmerDAO.deleteFarmer(selectedFarmerId);
                
                if (success) {
                    showSuccess("✅ Farmer deleted successfully!");
                    loadFarmers();
                    clearFields();
                } else {
                    showError("Failed to delete farmer!");
                }
                
            } catch (SQLException e) {
                showError("Error deleting farmer: " + e.getMessage());
            }
        }
    }
    
    // Search farmers
    private void searchFarmers() {
        String searchTerm = txtSearch.getText().trim();
        
        if (searchTerm.isEmpty()) {
            loadFarmers();
            return;
        }
        
        try {
            tableModel.setRowCount(0);
            List<LivestockFarmer> farmers = farmerDAO.searchFarmers(searchTerm);
            
            for (LivestockFarmer farmer : farmers) {
                Object[] row = {
                    farmer.getFarmerId(),
                    farmer.getFirstName(),
                    farmer.getLastName(),
                    farmer.getEmail(),
                    farmer.getPhone(),
                    farmer.getNic(),
                    farmer.getFarmLocation(),
                    farmer.getLivestockType(),
                    farmer.getLivestockCount()
                };
                tableModel.addRow(row);
            }
            
            if (farmers.isEmpty()) {
                showInfo("No farmers found");
            } else {
                showInfo("Found " + farmers.size() + " farmer(s)");
            }
            
        } catch (SQLException e) {
            showError("Error searching farmers: " + e.getMessage());
        }
    }
    
    // Clear fields
    private void clearFields() {
        txtFirstName.setText("");
        txtLastName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtNic.setText("");
        txtAddress.setText("");
        txtFarmLocation.setText("");
        txtFarmSize.setText("");
        cmbLivestockType.setSelectedIndex(0);
        txtLivestockCount.setText("");
        txtSearch.setText("");
        selectedFarmerId = -1;
        tblFarmers.clearSelection();
    }
    
    // Validate inputs
    private boolean validateInputs() {
        if (Validator.isEmpty(txtFirstName.getText())) {
            showWarning("First name is required!");
            txtFirstName.requestFocus();
            return false;
        }
        
        if (Validator.isEmpty(txtLastName.getText())) {
            showWarning("Last name is required!");
            txtLastName.requestFocus();
            return false;
        }
        
        String email = txtEmail.getText().trim();
        if (!Validator.isValidEmail(email)) {
            showWarning("Invalid email format!");
            txtEmail.requestFocus();
            return false;
        }
        
        String phone = txtPhone.getText().trim();
        if (!Validator.isValidPhone(phone)) {
            showWarning("Invalid phone number! (Format: 0xxxxxxxxx)");
            txtPhone.requestFocus();
            return false;
        }
        
        String nic = txtNic.getText().trim();
        if (!Validator.isValidNIC(nic)) {
            showWarning("Invalid NIC format!");
            txtNic.requestFocus();
            return false;
        }
        
        try {
            double farmSize = Double.parseDouble(txtFarmSize.getText().trim());
            if (!Validator.isPositiveNumber(farmSize)) {
                showWarning("Farm size must be positive!");
                txtFarmSize.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid farm size!");
            txtFarmSize.requestFocus();
            return false;
        }
        
        try {
            int count = Integer.parseInt(txtLivestockCount.getText().trim());
            if (!Validator.isPositiveInteger(count)) {
                showWarning("Livestock count must be positive!");
                txtLivestockCount.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showWarning("Invalid livestock count!");
            txtLivestockCount.requestFocus();
            return false;
        }
        
        return true;
    }
    
    // Message dialogs
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }
    
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new FarmerForm().setVisible(true));
    }
}