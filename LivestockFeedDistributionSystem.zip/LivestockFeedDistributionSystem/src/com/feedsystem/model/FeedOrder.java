package com.feedsystem.model;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * FeedOrder Model (POJO) - MAIN TRANSACTION
 */
public class FeedOrder {
    
    private int orderId;
    private int farmerId;
    private int productId;
    private Date orderDate;
    private Date deliveryDate;
    private int quantityKg;
    private double pricePerKg;
    private double totalAmount;
    private String deliveryAddress;
    private String paymentStatus;
    private String deliveryStatus;
    private String notes;
    private Timestamp createdAt;
    
    // From JOINs for display
    private String farmerName;
    private String farmerPhone;
    private String productName;
    private String feedType;
    
    // Default Constructor
    public FeedOrder() {
    }
    
    // Constructor without ID
    public FeedOrder(int farmerId, int productId, Date orderDate, Date deliveryDate,
                    int quantityKg, double pricePerKg, double totalAmount,
                    String deliveryAddress, String paymentStatus, String deliveryStatus, String notes) {
        this.farmerId = farmerId;
        this.productId = productId;
        this.orderDate = orderDate;
        this.deliveryDate = deliveryDate;
        this.quantityKg = quantityKg;
        this.pricePerKg = pricePerKg;
        this.totalAmount = totalAmount;
        this.deliveryAddress = deliveryAddress;
        this.paymentStatus = paymentStatus;
        this.deliveryStatus = deliveryStatus;
        this.notes = notes;
    }
    
    // Full Constructor
    public FeedOrder(int orderId, int farmerId, int productId, Date orderDate, Date deliveryDate,
                    int quantityKg, double pricePerKg, double totalAmount,
                    String deliveryAddress, String paymentStatus, String deliveryStatus, String notes) {
        this.orderId = orderId;
        this.farmerId = farmerId;
        this.productId = productId;
        this.orderDate = orderDate;
        this.deliveryDate = deliveryDate;
        this.quantityKg = quantityKg;
        this.pricePerKg = pricePerKg;
        this.totalAmount = totalAmount;
        this.deliveryAddress = deliveryAddress;
        this.paymentStatus = paymentStatus;
        this.deliveryStatus = deliveryStatus;
        this.notes = notes;
    }
    
    // Getters and Setters
    public int getOrderId() {
        return orderId;
    }
    
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    
    public int getFarmerId() {
        return farmerId;
    }
    
    public void setFarmerId(int farmerId) {
        this.farmerId = farmerId;
    }
    
    public int getProductId() {
        return productId;
    }
    
    public void setProductId(int productId) {
        this.productId = productId;
    }
    
    public Date getOrderDate() {
        return orderDate;
    }
    
    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
    
    public Date getDeliveryDate() {
        return deliveryDate;
    }
    
    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }
    
    public int getQuantityKg() {
        return quantityKg;
    }
    
    public void setQuantityKg(int quantityKg) {
        this.quantityKg = quantityKg;
    }
    
    public double getPricePerKg() {
        return pricePerKg;
    }
    
    public void setPricePerKg(double pricePerKg) {
        this.pricePerKg = pricePerKg;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    public String getDeliveryAddress() {
        return deliveryAddress;
    }
    
    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }
    
    public String getPaymentStatus() {
        return paymentStatus;
    }
    
    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
    
    public String getDeliveryStatus() {
        return deliveryStatus;
    }
    
    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }
    
    public String getNotes() {
        return notes;
    }
    
    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getFarmerName() {
        return farmerName;
    }
    
    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }
    
    public String getFarmerPhone() {
        return farmerPhone;
    }
    
    public void setFarmerPhone(String farmerPhone) {
        this.farmerPhone = farmerPhone;
    }
    
    public String getProductName() {
        return productName;
    }
    
    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public String getFeedType() {
        return feedType;
    }
    
    public void setFeedType(String feedType) {
        this.feedType = feedType;
    }
    
    @Override
    public String toString() {
        return "FeedOrder{" +
                "orderId=" + orderId +
                ", farmerId=" + farmerId +
                ", productId=" + productId +
                ", orderDate=" + orderDate +
                ", deliveryDate=" + deliveryDate +
                ", quantityKg=" + quantityKg +
                ", totalAmount=" + totalAmount +
                ", deliveryStatus='" + deliveryStatus + '\'' +
                '}';
    }
}