package com.feedsystem.model;

import java.sql.Timestamp;

/**
 * LivestockFarmer Model (POJO)
 */
public class LivestockFarmer {
    
    private int farmerId;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String nic;
    private String address;
    private String farmLocation;
    private double farmSize;
    private String livestockType;
    private int livestockCount;
    private Timestamp createdAt;
    
    // Default Constructor
    public LivestockFarmer() {
    }
    
    // Constructor without ID
    public LivestockFarmer(String firstName, String lastName, String email, String phone,
                          String nic, String address, String farmLocation, double farmSize,
                          String livestockType, int livestockCount) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.nic = nic;
        this.address = address;
        this.farmLocation = farmLocation;
        this.farmSize = farmSize;
        this.livestockType = livestockType;
        this.livestockCount = livestockCount;
    }
    
    // Full Constructor
    public LivestockFarmer(int farmerId, String firstName, String lastName, String email,
                          String phone, String nic, String address, String farmLocation,
                          double farmSize, String livestockType, int livestockCount) {
        this.farmerId = farmerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.nic = nic;
        this.address = address;
        this.farmLocation = farmLocation;
        this.farmSize = farmSize;
        this.livestockType = livestockType;
        this.livestockCount = livestockCount;
    }
    
    // Getters and Setters
    public int getFarmerId() {
        return farmerId;
    }
    
    public void setFarmerId(int farmerId) {
        this.farmerId = farmerId;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getNic() {
        return nic;
    }
    
    public void setNic(String nic) {
        this.nic = nic;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getFarmLocation() {
        return farmLocation;
    }
    
    public void setFarmLocation(String farmLocation) {
        this.farmLocation = farmLocation;
    }
    
    public double getFarmSize() {
        return farmSize;
    }
    
    public void setFarmSize(double farmSize) {
        this.farmSize = farmSize;
    }
    
    public String getLivestockType() {
        return livestockType;
    }
    
    public void setLivestockType(String livestockType) {
        this.livestockType = livestockType;
    }
    
    public int getLivestockCount() {
        return livestockCount;
    }
    
    public void setLivestockCount(int livestockCount) {
        this.livestockCount = livestockCount;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    // Helper method
    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    @Override
    public String toString() {
        return "LivestockFarmer{" +
                "farmerId=" + farmerId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", livestockType='" + livestockType + '\'' +
                ", livestockCount=" + livestockCount +
                '}';
    }
}