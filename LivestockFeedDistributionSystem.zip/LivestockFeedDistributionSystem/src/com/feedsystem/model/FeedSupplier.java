package com.feedsystem.model;

import java.sql.Timestamp;

/**
 * FeedSupplier Model (POJO)
 */
public class FeedSupplier {
    
    private int supplierId;
    private String companyName;
    private String contactPerson;
    private String email;
    private String phone;
    private String address;
    private String city;
    private String registrationNumber;
    private double rating;
    private Timestamp createdAt;
    
    // Default Constructor
    public FeedSupplier() {
    }
    
    // Constructor without ID
    public FeedSupplier(String companyName, String contactPerson, String email, String phone,
                       String address, String city, String registrationNumber, double rating) {
        this.companyName = companyName;
        this.contactPerson = contactPerson;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.city = city;
        this.registrationNumber = registrationNumber;
        this.rating = rating;
    }
    
    // Full Constructor
    public FeedSupplier(int supplierId, String companyName, String contactPerson, String email,
                       String phone, String address, String city, String registrationNumber, double rating) {
        this.supplierId = supplierId;
        this.companyName = companyName;
        this.contactPerson = contactPerson;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.city = city;
        this.registrationNumber = registrationNumber;
        this.rating = rating;
    }
    
    // Getters and Setters
    public int getSupplierId() {
        return supplierId;
    }
    
    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }
    
    public String getCompanyName() {
        return companyName;
    }
    
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    
    public String getContactPerson() {
        return contactPerson;
    }
    
    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    
    public String getRegistrationNumber() {
        return registrationNumber;
    }
    
    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }
    
    public double getRating() {
        return rating;
    }
    
    public void setRating(double rating) {
        this.rating = rating;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    @Override
    public String toString() {
        return "FeedSupplier{" +
                "supplierId=" + supplierId +
                ", companyName='" + companyName + '\'' +
                ", contactPerson='" + contactPerson + '\'' +
                ", city='" + city + '\'' +
                ", rating=" + rating +
                '}';
    }
}