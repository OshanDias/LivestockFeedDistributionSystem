package com.feedsystem.model;

import java.sql.Timestamp;

/**
 * FeedProduct Model (POJO)
 */
public class FeedProduct {
    
    private int productId;
    private int supplierId;
    private String productName;
    private String feedType;
    private String livestockType;
    private double pricePerKg;
    private int stockQuantity;
    private double proteinContent;
    private String manufacturer;
    private String description;
    private String status;
    private Timestamp createdAt;
    
    // From JOIN with feed_suppliers
    private String supplierName;
    
    // Default Constructor
    public FeedProduct() {
    }
    
    // Constructor without ID
    public FeedProduct(int supplierId, String productName, String feedType, String livestockType,
                      double pricePerKg, int stockQuantity, double proteinContent, 
                      String manufacturer, String description, String status) {
        this.supplierId = supplierId;
        this.productName = productName;
        this.feedType = feedType;
        this.livestockType = livestockType;
        this.pricePerKg = pricePerKg;
        this.stockQuantity = stockQuantity;
        this.proteinContent = proteinContent;
        this.manufacturer = manufacturer;
        this.description = description;
        this.status = status;
    }
    
    // Full Constructor
    public FeedProduct(int productId, int supplierId, String productName, String feedType,
                      String livestockType, double pricePerKg, int stockQuantity, 
                      double proteinContent, String manufacturer, String description, String status) {
        this.productId = productId;
        this.supplierId = supplierId;
        this.productName = productName;
        this.feedType = feedType;
        this.livestockType = livestockType;
        this.pricePerKg = pricePerKg;
        this.stockQuantity = stockQuantity;
        this.proteinContent = proteinContent;
        this.manufacturer = manufacturer;
        this.description = description;
        this.status = status;
    }
    
    // Getters and Setters
    public int getProductId() {
        return productId;
    }
    
    public void setProductId(int productId) {
        this.productId = productId;
    }
    
    public int getSupplierId() {
        return supplierId;
    }
    
    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }
    
    public String getProductName() {
        return productName;
    }
    
    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public String getFeedType() {
        return feedType;
    }
    
    public void setFeedType(String feedType) {
        this.feedType = feedType;
    }
    
    public String getLivestockType() {
        return livestockType;
    }
    
    public void setLivestockType(String livestockType) {
        this.livestockType = livestockType;
    }
    
    public double getPricePerKg() {
        return pricePerKg;
    }
    
    public void setPricePerKg(double pricePerKg) {
        this.pricePerKg = pricePerKg;
    }
    
    public int getStockQuantity() {
        return stockQuantity;
    }
    
    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }
    
    public double getProteinContent() {
        return proteinContent;
    }
    
    public void setProteinContent(double proteinContent) {
        this.proteinContent = proteinContent;
    }
    
    public String getManufacturer() {
        return manufacturer;
    }
    
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getSupplierName() {
        return supplierName;
    }
    
    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }
    
    @Override
    public String toString() {
        return "FeedProduct{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", feedType='" + feedType + '\'' +
                ", livestockType='" + livestockType + '\'' +
                ", pricePerKg=" + pricePerKg +
                ", stockQuantity=" + stockQuantity +
                '}';
    }
}