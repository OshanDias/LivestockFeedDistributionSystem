package com.feedsystem;

import com.feedsystem.view.LoginForm;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Main Entry Point - Livestock Feed Distribution System
 */
public class Main {
    
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("🐄 LIVESTOCK FEED DISTRIBUTION SYSTEM");
        System.out.println("========================================");
        System.out.println("📋 Project: Livestock Feed Distribution");
        System.out.println("👨‍💻 Developer: [Your Name]");
        System.out.println("🎨 Theme: Purple/Magenta");
        System.out.println("📐 Layout: Sidebar + Top-Bottom");
        System.out.println("========================================\n");
        
        // Set look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Launch Login Form
        SwingUtilities.invokeLater(() -> {
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
        });
        
        System.out.println("✅ Application started successfully!");
        System.out.println("🔐 Default Login Credentials:");
        System.out.println("   Username: admin");
        System.out.println("   Password: admin123");
        System.out.println("========================================\n");
    }
}