-- Create Database
DROP DATABASE IF EXISTS livestock_feed_distribution_db;
CREATE DATABASE livestock_feed_distribution_db;
USE livestock_feed_distribution_db;

-- Table 1: Feed Suppliers
CREATE TABLE feed_suppliers (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    address TEXT,
    city VARCHAR(50),
    registration_number VARCHAR(50) UNIQUE NOT NULL,
    rating DECIMAL(2,1) DEFAULT 0.0 COMMENT 'Rating out of 5.0',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table 2: Feed Products
CREATE TABLE feed_products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    supplier_id INT NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    feed_type ENUM('Grain', 'Pellets', 'Supplement', 'Mineral', 'Mixed') NOT NULL,
    livestock_type ENUM('Cattle', 'Poultry', 'Goat', 'Sheep', 'Pig', 'Multi-Purpose') NOT NULL,
    price_per_kg DECIMAL(10,2) NOT NULL,
    stock_quantity INT DEFAULT 0 COMMENT 'Stock in KG',
    protein_content DECIMAL(5,2) COMMENT 'Protein percentage',
    manufacturer VARCHAR(100),
    description TEXT,
    status ENUM('AVAILABLE', 'OUT_OF_STOCK', 'DISCONTINUED') DEFAULT 'AVAILABLE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES feed_suppliers(supplier_id) ON DELETE CASCADE
);

-- Table 3: Livestock Farmers
CREATE TABLE livestock_farmers (
    farmer_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    nic VARCHAR(20) UNIQUE NOT NULL,
    address TEXT,
    farm_location VARCHAR(100),
    farm_size DECIMAL(10,2) COMMENT 'Farm size in acres',
    livestock_type ENUM('Cattle', 'Poultry', 'Goat', 'Sheep', 'Pig', 'Mixed') NOT NULL,
    livestock_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table 4: Feed Orders (MAIN TRANSACTION TABLE)
CREATE TABLE feed_orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT NOT NULL,
    product_id INT NOT NULL,
    order_date DATE NOT NULL,
    delivery_date DATE NOT NULL,
    quantity_kg INT NOT NULL COMMENT 'Quantity in KG',
    price_per_kg DECIMAL(10,2) NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    delivery_address TEXT,
    payment_status ENUM('PENDING', 'PAID', 'PARTIAL') DEFAULT 'PENDING',
    delivery_status ENUM('PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED') DEFAULT 'PROCESSING',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES livestock_farmers(farmer_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES feed_products(product_id) ON DELETE CASCADE
);

-- Insert Sample Suppliers
INSERT INTO feed_suppliers (company_name, contact_person, email, phone, address, city, registration_number, rating) VALUES
('Ceylon Feed Mills', 'Anil Kumar', 'anil@ceylonfeed.lk', '0112345678', 'No. 45, Industrial Zone, Ratmalana', 'Colombo', 'REG-CF-001', 4.5),
('Lanka Livestock Feeds', 'Shanika Perera', 'shanika@lankafeeds.lk', '0332234567', 'No. 78, Factory Road, Kurunegala', 'Kurunegala', 'REG-LL-002', 4.8),
('Agro Feed Supplies', 'Rohan Silva', 'rohan@agrofeeds.lk', '0812223344', 'No. 23, Main Street, Anuradhapura', 'Anuradhapura', 'REG-AF-003', 4.2),
('Prime Animal Nutrition', 'Nimal Fernando', 'nimal@primenutrition.lk', '0372234455', 'No. 56, Industrial Estate, Matara', 'Matara', 'REG-PN-004', 4.6),
('Green Pasture Feeds', 'Kamala Jayasinghe', 'kamala@greenpasture.lk', '0252223366', 'No. 12, Zone B, Puttalam', 'Puttalam', 'REG-GP-005', 4.4);

-- Insert Sample Feed Products
INSERT INTO feed_products (supplier_id, product_name, feed_type, livestock_type, price_per_kg, stock_quantity, protein_content, manufacturer, description, status) VALUES
-- Cattle Feed
(1, 'Premium Dairy Feed', 'Pellets', 'Cattle', 85.00, 5000, 18.5, 'Ceylon Feed Mills', 'High protein pellets for dairy cattle', 'AVAILABLE'),
(2, 'Beef Cattle Mix', 'Mixed', 'Cattle', 75.00, 3000, 16.0, 'Lanka Livestock Feeds', 'Complete feed mix for beef cattle', 'AVAILABLE'),
(3, 'Calf Starter Feed', 'Grain', 'Cattle', 95.00, 2000, 20.0, 'Agro Feed Supplies', 'Nutritious starter feed for calves', 'AVAILABLE'),

-- Poultry Feed
(1, 'Layer Mash Premium', 'Grain', 'Poultry', 65.00, 8000, 17.0, 'Ceylon Feed Mills', 'Complete feed for laying hens', 'AVAILABLE'),
(2, 'Broiler Starter', 'Pellets', 'Poultry', 70.00, 6000, 22.0, 'Lanka Livestock Feeds', 'High protein feed for broiler chicks', 'AVAILABLE'),
(4, 'Poultry Grower Mix', 'Mixed', 'Poultry', 68.00, 4500, 19.0, 'Prime Animal Nutrition', 'Growth formula for young poultry', 'AVAILABLE'),

-- Goat Feed
(3, 'Goat Nutrition Plus', 'Pellets', 'Goat', 72.00, 2500, 15.5, 'Agro Feed Supplies', 'Complete nutrition for goats', 'AVAILABLE'),
(5, 'Goat Mineral Mix', 'Mineral', 'Goat', 120.00, 1000, 0.0, 'Green Pasture Feeds', 'Essential minerals for goats', 'AVAILABLE'),

-- Multi-Purpose
(4, 'Universal Livestock Feed', 'Mixed', 'Multi-Purpose', 80.00, 3500, 16.5, 'Prime Animal Nutrition', 'Suitable for multiple livestock types', 'AVAILABLE'),
(5, 'Protein Supplement Pro', 'Supplement', 'Multi-Purpose', 150.00, 1500, 35.0, 'Green Pasture Feeds', 'High protein supplement for all livestock', 'AVAILABLE'),

-- Sheep Feed
(2, 'Sheep Finisher Feed', 'Pellets', 'Sheep', 78.00, 2000, 16.0, 'Lanka Livestock Feeds', 'Finishing feed for sheep', 'AVAILABLE'),
(1, 'Lamb Creep Feed', 'Grain', 'Sheep', 88.00, 1500, 18.0, 'Ceylon Feed Mills', 'Creep feed for lambs', 'AVAILABLE');

-- Insert Sample Farmers
INSERT INTO livestock_farmers (first_name, last_name, email, phone, nic, address, farm_location, farm_size, livestock_type, livestock_count) VALUES
('Sunil', 'Bandara', 'sunil.bandara@farm.lk', '0771234567', '892345678V', 'No. 23, Farm Road, Matara', 'Matara District', 25.5, 'Cattle', 45),
('Niluka', 'Perera', 'niluka.perera@farm.lk', '0712345678', '915432109V', 'No. 67, Village Lane, Kurunegala', 'Kurunegala District', 18.0, 'Poultry', 2500),
('Ranjith', 'Silva', 'ranjith.silva@farm.lk', '0763456789', '872345678V', 'No. 45, Hill Road, Badulla', 'Badulla District', 30.0, 'Goat', 120),
('Kamani', 'Fernando', 'kamani.fernando@farm.lk', '0724567890', '905432109V', 'No. 89, Lake View, Polonnaruwa', 'Polonnaruwa District', 35.5, 'Cattle', 60),
('Pradeep', 'Wickramasinghe', 'pradeep.w@farm.lk', '0775678901', '883456789V', 'No. 12, Farm Estate, Ampara', 'Ampara District', 40.0, 'Mixed', 85);

-- Insert Sample Orders
INSERT INTO feed_orders (farmer_id, product_id, order_date, delivery_date, quantity_kg, price_per_kg, total_amount, delivery_address, payment_status, delivery_status, notes) VALUES
(1, 1, '2026-01-20', '2026-01-25', 500, 85.00, 42500.00, 'Same as farmer address', 'PAID', 'DELIVERED', 'Premium dairy feed for milking cows'),
(2, 4, '2026-01-22', '2026-01-27', 1000, 65.00, 65000.00, 'Poultry farm, Kurunegala', 'PAID', 'DELIVERED', 'Layer feed for 2500 hens'),
(3, 7, '2026-01-18', '2026-01-23', 300, 72.00, 21600.00, 'Goat farm, Hill Road, Badulla', 'PAID', 'DELIVERED', 'Regular monthly supply'),
(4, 2, '2026-01-25', '2026-01-30', 750, 75.00, 56250.00, 'Same as farmer address', 'PENDING', 'PROCESSING', 'Beef cattle feed - urgent'),
(5, 9, '2026-01-23', '2026-01-28', 600, 80.00, 48000.00, 'Mixed livestock farm, Ampara', 'PARTIAL', 'SHIPPED', 'Universal feed for mixed livestock'),
(1, 3, '2026-01-15', '2026-01-20', 200, 95.00, 19000.00, 'Same as farmer address', 'PAID', 'DELIVERED', 'Calf starter for young cattle'),
(2, 6, '2026-01-10', '2026-01-15', 800, 68.00, 54400.00, 'Poultry farm, Kurunegala', 'PAID', 'DELIVERED', 'Growth feed for broilers');

-- Display success message
SELECT 'Database created successfully!' AS Status;
SELECT 'Tables: feed_suppliers, feed_products, livestock_farmers, feed_orders' AS Info;
SELECT COUNT(*) AS Total_Suppliers FROM feed_suppliers;
SELECT COUNT(*) AS Total_Products FROM feed_products;
SELECT COUNT(*) AS Total_Farmers FROM livestock_farmers;
SELECT COUNT(*) AS Total_Orders FROM feed_orders;